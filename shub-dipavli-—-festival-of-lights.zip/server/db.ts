import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  User,
  DiyaContest,
  PrizeItem,
  ContestEntry,
  PaymentConfig,
  SiteSettings,
  WinnerRecord,
  AdminStats
} from '../src/types';
import {
  initialContests,
  initialPrizes,
  initialPaymentConfig,
  initialSiteSettings
} from './seedData';

export interface StoredUser extends User {
  passwordHash: string;
  salt: string;
}

export interface StoredSession {
  token: string;
  userId: string;
  role: 'client' | 'admin';
  expiresAt: number;
}

export interface AuditEntry {
  id: string;
  action: string;
  performedBy: string;
  details: string;
  timestamp: string;
}

export interface DatabaseSchema {
  users: StoredUser[];
  sessions: StoredSession[];
  contests: DiyaContest[];
  prizes: PrizeItem[];
  entries: ContestEntry[];
  paymentConfig: PaymentConfig;
  siteSettings: SiteSettings;
  winners: WinnerRecord[];
  auditLogs: AuditEntry[];
}

const DB_FILE = path.resolve(process.cwd(), 'data', 'db.json');

// Ensure data folder exists
const dataDir = path.dirname(DB_FILE);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

export function hashPassword(password: string, existingSalt?: string): { hash: string; salt: string } {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const checkHash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(checkHash, 'hex'));
}

export function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function generateTicketNumber(contestId: string): string {
  const prefix = contestId === 'diya-1' ? 'D1' : contestId === 'diya-2' ? 'D2' : 'D3';
  const randomPart = Math.floor(100000 + Math.random() * 900000);
  return `SD-${prefix}-${randomPart}`;
}

let dbCache: DatabaseSchema | null = null;

export function loadDatabase(): DatabaseSchema {
  if (dbCache) return dbCache;

  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      dbCache = JSON.parse(data);
      // Ensure Admin01 password is Admin@01
      const existingAdmin = dbCache?.users.find(u => u.username.toLowerCase() === 'admin01' && u.role === 'admin');
      if (existingAdmin) {
        const adminCreds = hashPassword('Admin@01');
        existingAdmin.passwordHash = adminCreds.hash;
        existingAdmin.salt = adminCreds.salt;
        existingAdmin.isActive = true;
        saveDatabase(dbCache!);
      }
      return dbCache!;
    } catch (e) {
      console.error('Failed to parse database file, re-initializing...', e);
    }
  }

  // Seed default admin: Admin01
  const adminCredentials = hashPassword('Admin@01');
  const adminUser: StoredUser = {
    id: 'user-admin-01',
    username: 'Admin01',
    fullName: 'Diwali Executive Administrator',
    phone: '+919876543210',
    role: 'admin',
    isActive: true,
    createdAt: new Date().toISOString(),
    passwordHash: adminCredentials.hash,
    salt: adminCredentials.salt
  };

  const initialDb: DatabaseSchema = {
    users: [adminUser],
    sessions: [],
    contests: initialContests,
    prizes: initialPrizes,
    entries: [],
    paymentConfig: initialPaymentConfig,
    siteSettings: initialSiteSettings,
    winners: [],
    auditLogs: [
      {
        id: crypto.randomUUID(),
        action: 'SYSTEM_BOOTSTRAP',
        performedBy: 'System',
        details: 'SHUB DIPAVLI platform database seeded with 3 Diya categories and 49 prize catalogs.',
        timestamp: new Date().toISOString()
      }
    ]
  };

  saveDatabase(initialDb);
  dbCache = initialDb;
  return dbCache;
}

export function saveDatabase(data: DatabaseSchema): void {
  dbCache = data;
  try {
    const tempFile = `${DB_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error('Failed to write database file:', err);
  }
}

export function getStats(): AdminStats {
  const db = loadDatabase();
  const validUsers = db.users.filter(u => u.role === 'client');
  const validEntries = db.entries;
  const verifiedEntries = validEntries.filter(e => e.status === 'verified');
  const pendingEntries = validEntries.filter(e => e.status === 'pending');
  const totalCollected = verifiedEntries.reduce((acc, curr) => acc + curr.amount, 0);

  return {
    totalUsers: validUsers.length,
    totalEntries: validEntries.length,
    pendingEntries: pendingEntries.length,
    verifiedEntries: verifiedEntries.length,
    totalCollected,
    activeContests: db.contests.filter(c => c.isActive).length
  };
}
