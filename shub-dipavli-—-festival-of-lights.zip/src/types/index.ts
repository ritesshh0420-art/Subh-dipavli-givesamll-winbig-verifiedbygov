export type UserRole = 'client' | 'admin';

export interface User {
  id: string;
  username: string;
  fullName: string;
  phone?: string;
  role: UserRole;
  isActive: boolean;
  createdAt: string;
}

export interface DiyaContest {
  id: string; // 'diya-1' | 'diya-2' | 'diya-3'
  title: string;
  titleHi: string;
  diyaNumber: number;
  entryFee: number;
  subtitle: string;
  subtitleHi: string;
  description: string;
  descriptionHi: string;
  themeColor: string;
  accentColor: string;
  bannerImage: string;
  isActive: boolean;
  totalPrizes: number;
  featuredPrizes: string[];
}

export interface PrizeItem {
  id: string;
  contestId: string; // 'diya-1' | 'diya-2' | 'diya-3'
  orderNumber: number;
  name: string;
  nameHi: string;
  category: 'cash' | 'electronics' | 'gold' | 'vehicle' | 'travel' | 'lifestyle' | 'home' | 'voucher';
  marketValue: string;
  imageUrl: string;
  description: string;
  descriptionHi: string;
  isVerified: boolean;
}

export type EntryStatus = 'pending' | 'verified' | 'rejected' | 'refunded';

export interface ContestEntry {
  id: string;
  ticketNumber: string;
  userId: string;
  username: string;
  fullName: string;
  phone: string;
  city: string;
  contestId: string;
  contestTitle: string;
  amount: number;
  utrNumber: string;
  paymentMethod: string;
  receiptImage?: string;
  status: EntryStatus;
  adminNotes?: string;
  verifiedAt?: string;
  createdAt: string;
}

export interface PaymentConfig {
  upiId: string;
  upiQrUrl: string;
  accountHolderName: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  paymentInstructions: string;
  paymentInstructionsHi: string;
  isEnabled: boolean;
  updatedAt: string;
}

export interface SiteSettings {
  websiteTitle: string;
  tagline: string;
  taglineHi: string;
  heroHeadline: string;
  heroHeadlineHi: string;
  heroSubheadline: string;
  heroSubheadlineHi: string;
  heroImageUrl: string;
  resultAnnouncementDate: string; // ISO date
  resultDisplayDate: string; // e.g. "7 NOVEMBER 2026"
  isResultPublished: boolean;
  contactPhone: string;
  contactWhatsApp: string;
  contactEmail: string;
  supportHours: string;
  supportHoursHi: string;
  officialRules: string;
  officialRulesHi: string;
  privacyPolicy: string;
  updatedAt: string;
}

export interface WinnerRecord {
  id: string;
  contestId: string;
  contestTitle: string;
  ticketNumber: string;
  prizeName: string;
  prizeImageUrl: string;
  winnerUsername: string; // masked for privacy: r***h
  winnerCity: string;
  drawnAt: string;
  drawAuditHash: string;
}

export interface AdminStats {
  totalUsers: number;
  totalEntries: number;
  pendingEntries: number;
  verifiedEntries: number;
  totalCollected: number;
  activeContests: number;
}
