import React, { useState } from 'react';
import { DiyaContest, PaymentConfig, ContestEntry, User } from '../types';
import { Language, translations } from '../lib/translations';
import { api } from '../lib/api';
import confetti from 'canvas-confetti';
import {
  X,
  Copy,
  Check,
  Upload,
  AlertCircle,
  ShieldCheck,
  QrCode,
  Building,
  Flame,
  ArrowRight
} from 'lucide-react';

interface ParticipationModalProps {
  isOpen: boolean;
  onClose: () => void;
  contest: DiyaContest | null;
  paymentConfig: PaymentConfig;
  currentUser: User | null;
  lang: Language;
  onOpenAuth: () => void;
  onSuccess: (entry: ContestEntry) => void;
}

export const ParticipationModal: React.FC<ParticipationModalProps> = ({
  isOpen,
  onClose,
  contest,
  paymentConfig,
  currentUser,
  lang,
  onOpenAuth,
  onSuccess
}) => {
  const t = translations[lang];

  const [fullName, setFullName] = useState(currentUser?.fullName || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [city, setCity] = useState('');
  const [utrNumber, setUtrNumber] = useState('');
  const [receiptImage, setReceiptImage] = useState<string>('');
  const [hasConsented, setHasConsented] = useState(true);
  const [isCopied, setIsCopied] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [completedEntry, setCompletedEntry] = useState<ContestEntry | null>(null);

  // Sync user details if changed
  React.useEffect(() => {
    if (currentUser) {
      if (!fullName) setFullName(currentUser.fullName);
      if (!phone && currentUser.phone) setPhone(currentUser.phone);
    }
  }, [currentUser]);

  if (!isOpen || !contest) return null;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(paymentConfig.upiId);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        setError('Image file is too large. Please select an image under 8MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setReceiptImage(reader.result as string);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!fullName.trim() || !phone.trim() || !utrNumber.trim()) {
      setError('Please fill in your Full Name, Mobile Number, and Payment UTR reference.');
      return;
    }

    if (utrNumber.trim().length < 6) {
      setError('Please enter a valid Bank or UPI UTR reference number (at least 6 characters).');
      return;
    }

    if (!hasConsented) {
      setError('Please acknowledge that you are 18+ and accept the official rules.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await api.submitEntry({
        contestId: contest.id,
        fullName: fullName.trim(),
        phone: phone.trim(),
        city: city.trim() || 'India',
        utrNumber: utrNumber.trim(),
        paymentMethod: 'UPI / Bank Transfer',
        receiptImage: receiptImage || undefined
      });

      // Celebration fireworks!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#ef4444', '#10b981', '#fbbf24']
        });
      } catch {
        // Safe confetti fallback
      }

      setCompletedEntry(res.entry);
      onSuccess(res.entry);
    } catch (err: any) {
      setError(err.message || 'Failed to submit participation entry. Please check your details.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl my-auto rounded-2xl bg-[#0c0d18] border border-amber-500/50 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-amber-900/40 bg-gradient-to-r from-amber-950/80 via-[#0c0d18] to-amber-950/60 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
              <Flame className="w-3.5 h-3.5 fill-amber-400" />
              <span>Contest Participation Checkout</span>
            </div>
            <h3
              className="text-xl font-bold text-amber-200 mt-1"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              {contest.title} · Entry Contribution ₹{contest.entryFee}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-amber-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* If completed, display celebratory ticket */}
        {completedEntry ? (
          <div className="p-6 sm:p-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Check className="w-8 h-8" />
            </div>

            <h4
              className="text-2xl font-black text-amber-200"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Shubh Deepawali! Entry Registered!
            </h4>

            <p className="text-sm text-amber-100/80 max-w-md mx-auto">
              Your contribution of <strong>₹{completedEntry.amount}</strong> for{' '}
              <strong>{completedEntry.contestTitle}</strong> has been logged.
            </p>

            {/* Generated Ticket Box */}
            <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/50 max-w-sm mx-auto shadow-inner">
              <span className="text-[11px] uppercase tracking-widest text-amber-400/80 block mb-1">
                Your Official Sealed Ticket Number
              </span>
              <span className="text-2xl sm:text-3xl font-black text-amber-300 tracking-wider font-mono">
                {completedEntry.ticketNumber}
              </span>
              <div className="mt-2 text-xs text-amber-200/60 flex items-center justify-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span>Status: Verification Pending Bank Audit</span>
              </div>
            </div>

            <p className="text-xs text-amber-200/70 max-w-md mx-auto">
              Our audit desk verifies bank transactions manually to ensure 100% genuine tickets. You can track this entry anytime in your personal dashboard.
            </p>

            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-slate-950 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 shadow-md transition-all cursor-pointer"
            >
              Continue Browsing Festival
            </button>
          </div>
        ) : (
          <div className="p-5 sm:p-6 space-y-6 max-h-[80vh] overflow-y-auto">
            {/* If user is not logged in */}
            {!currentUser && (
              <div className="p-4 rounded-xl bg-amber-950/60 border border-amber-600/50 flex items-center justify-between gap-4">
                <div className="text-xs text-amber-200">
                  <strong className="block text-amber-300 font-bold mb-0.5">Account Required to Participate</strong>
                  Please login or create a free account so your ticket number is securely linked to your dashboard.
                </div>
                <button
                  type="button"
                  onClick={onOpenAuth}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 shrink-0 transition-colors cursor-pointer"
                >
                  Login / Sign Up
                </button>
              </div>
            )}

            {/* Error Message */}
            {error && (
              <div className="p-3 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Payment Instructions & Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Left Column: Official UPI QR Code */}
              <div className="rounded-xl bg-slate-950 p-4 border border-amber-900/40 flex flex-col items-center justify-center text-center">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
                  <QrCode className="w-4 h-4" />
                  <span>Scan & Pay ₹{contest.entryFee}</span>
                </div>

                <div className="w-44 h-44 bg-white p-2 rounded-xl shadow-lg border border-amber-500/40 mb-3 flex items-center justify-center">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${encodeURIComponent(paymentConfig.upiId)}&pn=SHUB%20DIPAVLI&am=${contest.entryFee}&cu=INR`}
                    alt={`UPI QR Code for ₹${contest.entryFee}`}
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="w-full flex items-center justify-between p-2 rounded-lg bg-amber-950/40 border border-amber-800/40 text-xs text-amber-200">
                  <span className="font-mono truncate">{paymentConfig.upiId}</span>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 hover:bg-amber-500/40 font-semibold shrink-0 transition-colors"
                  >
                    {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{isCopied ? t.copied : 'Copy'}</span>
                  </button>
                </div>

                {/* Direct Android UPI Intent Link */}
                <a
                  href={`upi://pay?pa=${encodeURIComponent(paymentConfig.upiId)}&pn=SHUB%20DIPAVLI&am=${contest.entryFee}&cu=INR`}
                  className="mt-2.5 w-full py-2 px-3 rounded-lg text-center text-xs font-bold text-amber-300 bg-amber-950/80 hover:bg-amber-900 border border-amber-600/50 flex items-center justify-center gap-2 transition-colors"
                >
                  <span>📱 Tap to Open UPI App (GPay / PhonePe / Paytm)</span>
                </a>
              </div>

              {/* Right Column: Direct Bank Transfer Details */}
              <div className="rounded-xl bg-slate-950 p-4 border border-amber-900/40 flex flex-col justify-between text-xs text-amber-100/90 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-wider">
                  <Building className="w-4 h-4" />
                  <span>Bank Account Details</span>
                </div>

                <div className="space-y-1.5 pt-1">
                  <div>
                    <span className="text-amber-400/70 block text-[10px] uppercase">Account Holder</span>
                    <strong className="text-amber-200 font-semibold">{paymentConfig.accountHolderName}</strong>
                  </div>
                  <div>
                    <span className="text-amber-400/70 block text-[10px] uppercase">Bank Name</span>
                    <strong className="text-amber-200 font-semibold">{paymentConfig.bankName}</strong>
                  </div>
                  <div>
                    <span className="text-amber-400/70 block text-[10px] uppercase">Account Number</span>
                    <strong className="text-amber-300 font-mono text-sm tracking-wider">{paymentConfig.accountNumber}</strong>
                  </div>
                  <div>
                    <span className="text-amber-400/70 block text-[10px] uppercase">IFSC Code</span>
                    <strong className="text-amber-300 font-mono">{paymentConfig.ifscCode}</strong>
                  </div>
                </div>

                <div className="pt-2 border-t border-white/5 text-[11px] text-amber-200/70 leading-tight">
                  {lang === 'hi'
                    ? paymentConfig.paymentInstructionsHi || paymentConfig.paymentInstructions
                    : paymentConfig.paymentInstructions}
                </div>
              </div>
            </div>

            {/* Participation Form */}
            <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-amber-900/40">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-amber-300 mb-1">
                    {t.fullName} *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Enter full legal name"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-300 mb-1">
                    {t.mobileNumber} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 9876543210 (for SMS updates)"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-amber-300 mb-1">
                    {t.cityState} *
                  </label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="e.g. Mumbai, Maharashtra"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-300 mb-1">
                    {t.utrLabel} *
                  </label>
                  <input
                    type="text"
                    required
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value)}
                    placeholder="12-digit UTR / UPI Ref ID"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-500/50 text-amber-300 font-mono placeholder:text-amber-300/40 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Upload Payment Screenshot */}
              <div>
                <label className="block text-xs font-semibold text-amber-300 mb-1">
                  {t.uploadReceipt}
                </label>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 border border-dashed border-amber-700/60 hover:border-amber-500 text-xs text-amber-200 cursor-pointer transition-colors">
                    <Upload className="w-4 h-4 text-amber-400" />
                    <span>{receiptImage ? 'Change Screenshot' : 'Select Screenshot (JPG/PNG)'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                  {receiptImage && (
                    <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Image Attached
                    </span>
                  )}
                </div>
              </div>

              {/* Consent Checkbox */}
              <label className="flex items-start gap-2 pt-1 text-xs text-amber-200/80 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasConsented}
                  onChange={(e) => setHasConsented(e.target.checked)}
                  className="mt-0.5 rounded border-amber-700 text-amber-500 focus:ring-amber-500"
                />
                <span>
                  I confirm that I am 18 years or older, an Indian citizen, and I agree to the{' '}
                  <span className="text-amber-300 underline">Official Rules</span> and understand winners are chosen via a transparent audited draw.
                </span>
              </label>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting || !currentUser}
                className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-amber-500/25 active:scale-[0.98] transition-all cursor-pointer"
              >
                <span>{isSubmitting ? 'Registering Entry...' : `${t.submitEntryBtn} (₹${contest.entryFee})`}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-amber-200/60">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Audited Ledger Verification · Encrypted User Protection</span>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
