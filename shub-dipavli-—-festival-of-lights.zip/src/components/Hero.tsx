import React from 'react';
import { Language, translations } from '../lib/translations';
import { SiteSettings } from '../types';
import { Sparkles, Gift, ShieldCheck, Flame, ArrowRight } from 'lucide-react';
import { DiyaFlame, DiyaLampSvg } from './DiwaliDecorations';

interface HeroProps {
  lang: Language;
  settings: SiteSettings;
  onExploreClick: () => void;
  onViewCatalogClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  lang,
  settings,
  onExploreClick,
  onViewCatalogClick
}) => {
  const t = translations[lang];

  return (
    <section className="relative overflow-hidden pt-6 pb-14 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="relative rounded-3xl overflow-hidden border border-amber-600/30 bg-gradient-to-b from-amber-950/40 via-slate-950/90 to-[#0b0c16] shadow-2xl">
          {/* Background Hero Image with measured overlay scrim */}
          <div className="absolute inset-0 z-0">
            <img
              src={settings.heroImageUrl?.replace('/src/assets/images/', '/images/') || '/images/hero_diwali_festival_1793461228323.jpg'}
              alt="Diwali Festival Celebration"
              className="w-full h-full object-cover object-center opacity-35 filter brightness-95"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0b0c16] via-[#0b0c16]/75 to-transparent" />
            <div className="absolute inset-0 bg-radial-gradient from-transparent via-[#0b0c16]/50 to-[#0b0c16]" />
          </div>

          {/* Hero Content */}
          <div className="relative z-10 px-6 sm:px-12 py-12 sm:py-20 text-center max-w-4xl mx-auto flex flex-col items-center">
            {/* Auspicious Diya Emblem */}
            <div className="relative mb-5 flex flex-col items-center">
              <div className="relative -mb-2 z-10">
                <DiyaFlame size="md" />
              </div>
              <DiyaLampSvg className="w-20 h-14" />
            </div>

            {/* Festive Lead Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-widest uppercase mb-4 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.heroTag}</span>
            </div>

            {/* Grand Title */}
            <h1
              className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 uppercase leading-tight sm:leading-tight mb-5"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              {lang === 'hi'
                ? settings.heroHeadlineHi || t.heroTitle
                : settings.heroHeadline || t.heroTitle}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-xl text-amber-100/90 max-w-2xl font-light leading-relaxed mb-8">
              {lang === 'hi'
                ? settings.heroSubheadlineHi || t.heroSubtitle
                : settings.heroSubheadline || t.heroSubtitle}
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
              <button
                onClick={onExploreClick}
                className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-xl shadow-amber-500/30 transform hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
              >
                <Flame className="w-4 h-4 text-slate-950 fill-amber-900" />
                <span>{t.exploreDiyas}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onViewCatalogClick}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-semibold text-sm text-amber-200 bg-amber-950/60 hover:bg-amber-900/60 border border-amber-600/50 hover:border-amber-500/80 transition-all cursor-pointer"
              >
                <Gift className="w-4 h-4 text-amber-400" />
                <span>{t.viewAllPrizes} (49 Mega Gifts)</span>
              </button>
            </div>

            {/* Trust and Integrity Markers */}
            <div className="mt-10 pt-6 border-t border-amber-900/40 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs text-amber-200/80 w-full max-w-2xl">
              <div className="flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>100% Verified Prize Availability</span>
              </div>
              <div className="flex items-center justify-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Transparent Cryptographic Draw</span>
              </div>
              <div className="col-span-2 sm:col-span-1 flex items-center justify-center gap-1.5">
                <Gift className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Free Pan-India Delivery</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
