import React, { useState, useMemo } from 'react';
import { PrizeItem, DiyaContest } from '../types';
import { Language, translations } from '../lib/translations';
import { X, Search, ShieldCheck, Flame, Gift } from 'lucide-react';

interface PrizeCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  prizes: PrizeItem[];
  contests: DiyaContest[];
  selectedContestId?: string;
  lang: Language;
  onParticipateInContest: (contest: DiyaContest) => void;
}

export const PrizeCatalogModal: React.FC<PrizeCatalogModalProps> = ({
  isOpen,
  onClose,
  prizes,
  contests,
  selectedContestId,
  lang,
  onParticipateInContest
}) => {
  const t = translations[lang];
  const [activeContestFilter, setActiveContestFilter] = useState<string>(selectedContestId || 'all');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Sync prop changes
  React.useEffect(() => {
    if (selectedContestId) {
      setActiveContestFilter(selectedContestId);
    }
  }, [selectedContestId]);

  const filteredPrizes = useMemo(() => {
    return prizes.filter((prize) => {
      const matchesContest =
        activeContestFilter === 'all' || prize.contestId === activeContestFilter;
      const matchesCategory =
        categoryFilter === 'all' || prize.category === categoryFilter;
      const matchesSearch =
        prize.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (prize.nameHi && prize.nameHi.includes(searchQuery)) ||
        prize.marketValue.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesContest && matchesCategory && matchesSearch;
    });
  }, [prizes, activeContestFilter, categoryFilter, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-5xl max-h-[92vh] flex flex-col rounded-2xl bg-[#0c0d18] border border-amber-500/40 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-amber-900/40 bg-gradient-to-r from-amber-950/80 via-[#0c0d18] to-amber-950/60 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
              <Gift className="w-3.5 h-3.5" />
              <span>{t.navPrizes} ({prizes.length} Total Curated Items)</span>
            </div>
            <h3
              className="text-xl sm:text-2xl font-black text-amber-200 mt-1"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Festive Lucky Draw Prize Catalog
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-amber-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters and Search Bar */}
        <div className="p-4 sm:p-5 border-b border-white/5 bg-slate-950/60 space-y-3">
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            {/* Contest Diya Selector */}
            <div className="flex items-center gap-1.5 p-1 bg-amber-950/40 rounded-xl border border-amber-900/40 w-full sm:w-auto overflow-x-auto">
              <button
                onClick={() => setActiveContestFilter('all')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  activeContestFilter === 'all'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-amber-200/80 hover:text-amber-100'
                }`}
              >
                All Diyas (49)
              </button>
              {contests.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActiveContestFilter(c.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                    activeContestFilter === c.id
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-amber-200/80 hover:text-amber-100'
                  }`}
                >
                  {c.title} (₹{c.entryFee})
                </button>
              ))}
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400/60" />
              <input
                type="text"
                placeholder="Search prizes, gold, cars..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900/90 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Secondary Type Filter */}
          <div className="flex items-center gap-2 overflow-x-auto text-xs text-amber-300/80 pb-1">
            <span className="text-[11px] text-amber-400 font-semibold uppercase tracking-wider shrink-0">Type:</span>
            {['all', 'electronics', 'vehicle', 'gold', 'travel', 'home', 'lifestyle', 'voucher', 'cash'].map((type) => (
              <button
                key={type}
                onClick={() => setCategoryFilter(type)}
                className={`px-2.5 py-1 rounded-md capitalize transition-colors whitespace-nowrap ${
                  categoryFilter === type
                    ? 'bg-amber-900/60 text-amber-200 border border-amber-700/60 font-semibold'
                    : 'text-amber-200/60 hover:text-amber-100'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Prizes Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 max-h-[60vh]">
          {filteredPrizes.length === 0 ? (
            <div className="py-12 text-center text-amber-200/60">
              <p>No prizes match your search criteria.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
              {filteredPrizes.map((prize) => {
                const contest = contests.find((c) => c.id === prize.contestId);
                return (
                  <div
                    key={prize.id}
                    className="group rounded-xl bg-slate-900/70 border border-amber-900/30 hover:border-amber-500/50 transition-all overflow-hidden flex flex-col justify-between"
                  >
                    {/* Prize Image Container */}
                    <div className="relative aspect-[16/10] bg-slate-950 overflow-hidden">
                      <img
                        src={prize.imageUrl}
                        alt={prize.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-slate-950/80 border border-amber-500/30 text-[10px] font-bold text-amber-300">
                        #{prize.orderNumber} in {contest?.title.split('—')[0].trim() || prize.contestId}
                      </div>
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-amber-500/90 text-slate-950 text-[10px] font-black tabular-nums">
                        {prize.marketValue}
                      </div>
                    </div>

                    {/* Prize Info */}
                    <div className="p-3.5 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="text-[10px] uppercase font-semibold text-amber-400/80 tracking-wider">
                            {prize.category}
                          </span>
                          <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-medium">
                            <ShieldCheck className="w-3 h-3" /> Verified
                          </span>
                        </div>

                        <h4 className="text-sm font-bold text-amber-100 group-hover:text-amber-300 transition-colors line-clamp-1">
                          {lang === 'hi' ? prize.nameHi || prize.name : prize.name}
                        </h4>

                        <p className="mt-1 text-xs text-amber-200/70 line-clamp-2 leading-relaxed">
                          {lang === 'hi' ? prize.descriptionHi || prize.description : prize.description}
                        </p>
                      </div>

                      {/* Quick Participate CTA for this category */}
                      {contest && (
                        <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between">
                          <span className="text-[11px] text-amber-300/80 font-medium">
                            Entry: <strong className="text-amber-300">₹{contest.entryFee}</strong>
                          </span>
                          <button
                            onClick={() => {
                              onClose();
                              onParticipateInContest(contest);
                            }}
                            className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
                          >
                            <Flame className="w-3 h-3 fill-slate-950" />
                            <span>Participate</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-amber-900/40 text-center text-xs text-amber-200/60">
          Showing {filteredPrizes.length} of {prizes.length} official festive prizes. All items are verified available by administration.
        </div>
      </div>
    </div>
  );
};
