import React from 'react';
import { DiyaContest, PrizeItem } from '../types';
import { Language, translations } from '../lib/translations';
import { Sparkles, Eye, Flame, Award, ChevronRight } from 'lucide-react';
import { DiyaFlame, DiyaLampSvg } from './DiwaliDecorations';

interface DiyaCategoriesProps {
  lang: Language;
  contests: DiyaContest[];
  prizes: PrizeItem[];
  onSelectDiya: (contest: DiyaContest) => void;
  onViewPrizes: (contest: DiyaContest) => void;
}

export const DiyaCategories: React.FC<DiyaCategoriesProps> = ({
  lang,
  contests,
  prizes,
  onSelectDiya,
  onViewPrizes
}) => {
  const t = translations[lang];

  return (
    <section id="categories" className="py-12 px-4 sm:px-6 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-amber-400 uppercase mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>FESTIVE LUCKY DRAW CATEGORIES</span>
        </div>
        <h2
          className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500 uppercase tracking-tight"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          {lang === 'hi' ? 'शुभ दीया उत्सव श्रेणियां' : 'Auspicious Diya Categories'}
        </h2>
        <p className="mt-2 text-sm sm:text-base text-amber-200/80">
          {lang === 'hi'
            ? 'अपनी पसंद का दीया चुनें, आकर्षक पुरस्कार देखें और उत्सव लकी ड्रा में भाग लें।'
            : 'Select your auspicious Diya, explore genuine prizes, and participate with your entry contribution.'}
        </p>
      </div>

      {/* 3 Diya Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-stretch">
        {contests.map((contest, index) => {
          const contestPrizes = prizes.filter(p => p.contestId === contest.id);
          const topThumbnails = contestPrizes.slice(0, 4);

          // Card accent color styles
          const borderHighlight =
            index === 0
              ? 'border-amber-500/40 hover:border-amber-400/70 group-hover:shadow-[0_0_35px_rgba(245,158,11,0.25)]'
              : index === 1
              ? 'border-orange-500/40 hover:border-orange-400/70 group-hover:shadow-[0_0_35px_rgba(249,115,22,0.25)]'
              : 'border-purple-500/40 hover:border-purple-400/70 group-hover:shadow-[0_0_35px_rgba(168,85,247,0.25)]';

          const gradientHeader =
            index === 0
              ? 'from-amber-950/80 via-slate-900/90 to-amber-950/40'
              : index === 1
              ? 'from-orange-950/80 via-slate-900/90 to-orange-950/40'
              : 'from-purple-950/80 via-slate-900/90 to-purple-950/40';

          return (
            <div
              key={contest.id}
              className={`group relative rounded-2xl bg-[#0e101f] border ${borderHighlight} transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-xl`}
            >
              {/* Card Top Banner with Diya Visual */}
              <div className={`p-6 bg-gradient-to-b ${gradientHeader} text-center relative border-b border-white/5`}>
                {/* Diya Number Badge */}
                <div className="absolute top-4 left-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/80 border border-amber-500/30 text-amber-300 text-xs font-bold">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>DIYA {contest.diyaNumber}</span>
                </div>

                {/* Entry Fee Pill Tag */}
                <div className="absolute top-4 right-4 inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/50 text-amber-300 text-xs font-extrabold tabular-nums">
                  <span>₹{contest.entryFee}</span>
                </div>

                {/* Center Glowing Diya Graphic */}
                <div className="pt-6 pb-2 flex flex-col items-center">
                  <div className="relative -mb-1.5 z-10">
                    <DiyaFlame size="md" />
                  </div>
                  <DiyaLampSvg className="w-20 h-14" />
                </div>

                {/* Diya Title */}
                <h3
                  className="text-xl sm:text-2xl font-black text-amber-200 tracking-wide mt-2"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  {lang === 'hi' ? contest.titleHi : contest.title}
                </h3>

                <p className="text-xs text-amber-300/80 mt-1 font-medium">
                  {lang === 'hi' ? contest.subtitleHi : contest.subtitle}
                </p>

                {/* Large Price Highlight */}
                <div className="mt-3 text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-400 tabular-nums font-mono">
                  ₹{contest.entryFee}
                  <span className="text-xs text-amber-200/60 font-sans font-normal ml-1.5">
                    {t.entryFeeLabel}
                  </span>
                </div>
              </div>

              {/* Card Body & Product Thumbnails */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  {/* Category prize count */}
                  <div className="flex items-center justify-between text-xs text-amber-200/70 mb-3 pb-2 border-b border-white/5">
                    <span className="font-semibold text-amber-300">{contestPrizes.length} {t.prizesCountText}</span>
                    <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> All Verified
                    </span>
                  </div>

                  {/* Product Thumbnails Grid */}
                  <div className="grid grid-cols-4 gap-2 mb-4">
                    {topThumbnails.map((prize) => (
                      <div
                        key={prize.id}
                        className="group/thumb relative rounded-lg overflow-hidden border border-amber-900/40 bg-slate-950 aspect-square"
                        title={prize.name}
                      >
                        <img
                          src={prize.imageUrl}
                          alt={prize.name}
                          className="w-full h-full object-cover group-hover/thumb:scale-110 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            // Fallback gradient if image fails
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent flex items-end p-1">
                          <span className="text-[9px] text-amber-100 font-semibold line-clamp-1 leading-tight">
                            {prize.name.split(' ')[0]}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Highlights list */}
                  <ul className="space-y-1.5 mb-5 text-xs text-amber-100/80">
                    {contest.featuredPrizes.map((fp, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                        <span className="line-clamp-1">{fp}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2 pt-2 border-t border-white/5">
                  {/* Participate Button (Required trigger for Diya selection popup) */}
                  <button
                    onClick={() => onSelectDiya(contest)}
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-md shadow-amber-500/20 active:scale-[0.98] transition-all cursor-pointer"
                  >
                    <Flame className="w-4 h-4 fill-slate-950" />
                    <span>{t.participateBtn} (₹{contest.entryFee})</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  {/* View Prizes Catalog Button */}
                  <button
                    onClick={() => onViewPrizes(contest)}
                    className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold text-amber-200 bg-amber-950/40 hover:bg-amber-900/40 border border-amber-800/40 hover:border-amber-700/60 transition-colors cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-amber-400" />
                    <span>{t.viewPrizesBtn} ({contestPrizes.length})</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
