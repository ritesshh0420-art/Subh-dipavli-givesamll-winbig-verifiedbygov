import React from 'react';

export const DiyaFlame: React.FC<{ size?: 'sm' | 'md' | 'lg' | 'xl' }> = ({ size = 'md' }) => {
  const dimensions = {
    sm: 'w-4 h-6',
    md: 'w-6 h-9',
    lg: 'w-8 h-12',
    xl: 'w-12 h-18'
  }[size];

  return (
    <div className={`relative ${dimensions} flex items-center justify-center animate-flicker pointer-events-none select-none`}>
      {/* Outer Golden Glow */}
      <div className="absolute inset-0 bg-gradient-to-t from-orange-600 via-amber-500 to-yellow-300 rounded-full blur-[3px] opacity-90 scale-105" />
      {/* Inner Pure Flame Core */}
      <div className="relative w-3/4 h-full bg-gradient-to-t from-red-600 via-amber-400 to-yellow-100 rounded-full clip-flame" />
      {/* Center White Hot Tip */}
      <div className="absolute bottom-1 w-1/3 h-1/2 bg-white/90 rounded-full blur-[1px]" />
    </div>
  );
};

export const DiyaLampSvg: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg
    viewBox="0 0 100 65"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`${className} drop-shadow-[0_8px_16px_rgba(245,158,11,0.35)]`}
  >
    {/* Earthen Clay Diya Base */}
    <path
      d="M10 32C10 50 28 60 50 60C72 60 90 50 90 32C90 26 80 28 50 28C20 28 10 26 10 32Z"
      fill="url(#clayGradient)"
    />
    {/* Diya Rim with Golden Carving */}
    <path
      d="M8 32C8 28 25 24 50 24C75 24 92 28 92 32C92 36 75 40 50 40C25 40 8 36 8 32Z"
      fill="url(#goldRimGradient)"
    />
    <path
      d="M12 32C12 29 28 26 50 26C72 26 88 29 88 32C88 35 72 38 50 38C28 38 12 35 12 32Z"
      fill="#451a03"
    />
    {/* Wick Spout */}
    <path
      d="M48 24C48 20 50 16 52 14C53 16 54 20 52 24Z"
      fill="#1c1917"
    />
    {/* Gradients */}
    <defs>
      <linearGradient id="clayGradient" x1="50" y1="28" x2="50" y2="60" gradientUnits="userSpaceOnUse">
        <stop stopColor="#9a3412" />
        <stop offset="0.6" stopColor="#7c2d12" />
        <stop offset="1" stopColor="#431407" />
      </linearGradient>
      <linearGradient id="goldRimGradient" x1="8" y1="32" x2="92" y2="32" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f59e0b" />
        <stop offset="0.5" stopColor="#fef08a" />
        <stop offset="1" stopColor="#d97706" />
      </linearGradient>
    </defs>
  </svg>
);

export const FloatingSparkles: React.FC = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none z-0">
      {/* Ambient glowing orbs */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
      <div className="absolute top-1/3 right-10 w-80 h-80 bg-orange-600/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-red-600/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/2 right-1/3 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl" />
    </div>
  );
};
