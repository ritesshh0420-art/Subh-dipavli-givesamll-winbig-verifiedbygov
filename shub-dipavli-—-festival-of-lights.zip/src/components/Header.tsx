import React from 'react';
import { User } from '../types';
import { Language, translations } from '../lib/translations';
import { Sparkles, User as UserIcon, Shield, Globe } from 'lucide-react';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  currentUser: User | null;
  onOpenAuth: () => void;
  onOpenDashboard: () => void;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  currentUser,
  onOpenAuth,
  onOpenDashboard,
  onOpenAdmin
}) => {
  const t = translations[lang];

  return (
    <header className="sticky top-0 z-50 bg-[#0c0d18]/90 backdrop-blur-md border-b border-amber-900/40 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <a
          href="#"
          className="text-lg sm:text-xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 whitespace-nowrap shrink-0 flex items-center gap-2 hover:opacity-95 transition-opacity"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          <span className="text-xl">🪔</span>
          <span>{t.brandName}</span>
        </a>

        {/* Zone 2: 4-5 Navigation Links (Clean single-line text links) */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-amber-100/80">
          <a
            href="#categories"
            className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t.navCategories}
          </a>
          <a
            href="#prizes"
            className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t.navPrizes}
          </a>
          <a
            href="#results"
            className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t.navResults}
          </a>
          <a
            href="#rules"
            className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t.navRules}
          </a>
          <a
            href="#contact"
            className="hover:text-amber-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t.navContact}
          </a>
        </nav>

        {/* Zone 3: Primary Action & Language Toggle */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language Toggle */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-amber-200/90 bg-amber-950/60 border border-amber-800/40 rounded-lg hover:bg-amber-900/50 hover:border-amber-700/60 transition-colors whitespace-nowrap shrink-0"
            title="Switch Language / भाषा बदलें"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'en' ? 'हिन्दी' : 'English'}</span>
          </button>

          {/* User / Admin Action Button */}
          {currentUser ? (
            currentUser.role === 'admin' ? (
              <button
                onClick={onOpenAdmin}
                className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 rounded-lg shadow-sm shadow-amber-500/20 transition-all whitespace-nowrap shrink-0"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>{t.adminPanel}</span>
              </button>
            ) : (
              <button
                onClick={onOpenDashboard}
                className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-amber-100 bg-amber-900/50 border border-amber-700/60 hover:bg-amber-800/60 rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0"
              >
                <UserIcon className="w-3.5 h-3.5 text-amber-400" />
                <span className="max-w-[120px] truncate">{currentUser.fullName || currentUser.username}</span>
              </button>
            )
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 rounded-lg shadow-md shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all whitespace-nowrap shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5 text-slate-950" />
              <span>{t.login} / {t.register}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
