import React, { useState } from 'react';
import { User } from '../types';
import { Language, translations } from '../lib/translations';
import { api, tokenStorage } from '../lib/api';
import { X, Lock, User as UserIcon, Phone, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import { DiyaFlame, DiyaLampSvg } from './DiwaliDecorations';

interface ClientAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onAuthSuccess: (user: User) => void;
}

export const ClientAuthModal: React.FC<ClientAuthModalProps> = ({
  isOpen,
  onClose,
  lang,
  onAuthSuccess
}) => {
  const t = translations[lang];
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [securityAnswer, setSecurityAnswer] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const resetForm = () => {
    setError(null);
    setSuccessMsg(null);
    setPassword('');
    setConfirmPassword('');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const res = await api.login({ username: username.trim(), password });
      tokenStorage.set(res.token);
      onAuthSuccess(res.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Invalid username or password. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please verify your password.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    setIsLoading(true);

    try {
      const res = await api.register({
        username: username.trim(),
        fullName: fullName.trim(),
        password,
        phone: phone.trim()
      });
      tokenStorage.set(res.token);
      onAuthSuccess(res.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Registration failed. Username may already exist.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const res = await api.forgotPassword({
        username: username.trim(),
        phone: phone.trim(),
        securityAnswer: securityAnswer.trim()
      });
      setSuccessMsg(res.message);
    } catch (err: any) {
      setError(err.message || 'Unable to submit password recovery request.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-md rounded-2xl bg-gradient-to-b from-[#141224] via-[#0d0e1c] to-[#0a0b14] border border-amber-500/50 p-6 sm:p-8 shadow-2xl overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-amber-300/70 hover:text-amber-100 hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Diya Header Artwork */}
        <div className="flex flex-col items-center justify-center pt-1 pb-3 text-center">
          <div className="relative -mb-1 z-10">
            <DiyaFlame size="sm" />
          </div>
          <DiyaLampSvg className="w-14 h-10" />
          <h3
            className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500 mt-2"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            {mode === 'login'
              ? 'Client Access Portal'
              : mode === 'register'
              ? 'Join Festive Celebration'
              : 'Password Recovery'}
          </h3>
          <p className="text-xs text-amber-200/70 mt-0.5">
            {mode === 'login'
              ? 'Log in to view your tickets and participate'
              : mode === 'register'
              ? 'Create a secure client account'
              : 'Recover your account access safely'}
          </p>
        </div>

        {/* Mode Navigation Tabs */}
        {mode !== 'forgot' && (
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-950 rounded-xl border border-amber-900/40 mb-5">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                resetForm();
              }}
              className={`py-1.5 text-xs font-bold rounded-lg transition-colors ${
                mode === 'login'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-amber-200/70 hover:text-amber-100'
              }`}
            >
              {t.login}
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                resetForm();
              }}
              className={`py-1.5 text-xs font-bold rounded-lg transition-colors ${
                mode === 'register'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-amber-200/70 hover:text-amber-100'
              }`}
            >
              {t.register}
            </button>
          </div>
        )}

        {/* Alerts */}
        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 mb-4 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* LOGIN FORM */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                Username
              </label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400/60" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-amber-300">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setMode('forgot');
                    resetForm();
                  }}
                  className="text-[11px] text-amber-400 hover:text-amber-300 underline"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400/60" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-md shadow-amber-500/20 active:scale-[0.98] transition-all cursor-pointer"
            >
              <span>{isLoading ? 'Verifying...' : 'Login to Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-center pt-2 text-xs text-amber-200/70">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  resetForm();
                }}
                className="text-amber-400 font-bold hover:underline"
              >
                Create Account
              </button>
            </div>
          </form>
        )}

        {/* REGISTER FORM */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Ramesh Kumar"
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                Username *
              </label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Choose unique username"
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                Mobile Number (for SMS & prize verification)
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400/60" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="10-digit Indian Mobile"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-amber-300 mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-amber-300 mb-1">
                  Confirm Password *
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat password"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-md shadow-amber-500/20 active:scale-[0.98] transition-all cursor-pointer"
            >
              <span>{isLoading ? 'Creating Account...' : 'Register & Enter Festival'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-center pt-1 text-xs text-amber-200/70">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  resetForm();
                }}
                className="text-amber-400 font-bold hover:underline"
              >
                Login
              </button>
            </div>
          </form>
        )}

        {/* FORGOT PASSWORD FORM */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgotPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                Your Username *
              </label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username used during registration"
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                Registered Contact Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Mobile number linked to tickets"
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                Ticket Reference or Verification Hint
              </label>
              <input
                type="text"
                value={securityAnswer}
                onChange={(e) => setSecurityAnswer(e.target.value)}
                placeholder="e.g. Any previous ticket number or city"
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-300/40 focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors cursor-pointer"
            >
              {isLoading ? 'Submitting...' : 'Request Password Reset Key'}
            </button>

            <button
              type="button"
              onClick={() => {
                setMode('login');
                resetForm();
              }}
              className="w-full text-center text-xs text-amber-400 hover:underline pt-1"
            >
              Back to Client Login
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
