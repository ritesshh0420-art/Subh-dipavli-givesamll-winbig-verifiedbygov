import React from 'react';
import { SiteSettings } from '../types';
import { Language, translations } from '../lib/translations';
import { Phone, Mail, Clock, MessageSquare, ShieldCheck, Lock } from 'lucide-react';
import { DiyaFlame, DiyaLampSvg } from './DiwaliDecorations';

interface FooterProps {
  settings: SiteSettings;
  lang: Language;
  onOpenRules: () => void;
  onOpenResults: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  lang,
  onOpenRules,
  onOpenResults,
  onOpenAdmin
}) => {
  const t = translations[lang];

  return (
    <footer id="contact" className="relative bg-[#07080e] border-t border-amber-900/40 text-amber-100/80 pt-12 pb-8 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto space-y-10">
        {/* Top Tier: Brand, Greeting, and Contact */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-center">
                <div className="relative -mb-1 z-10">
                  <DiyaFlame size="sm" />
                </div>
                <DiyaLampSvg className="w-12 h-8" />
              </div>
              <h3
                className="text-xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                {t.brandName}
              </h3>
            </div>

            <p className="text-xs text-amber-200/70 max-w-md leading-relaxed">
              Celebrate the auspicious Festival of Lights with blessings of Goddess Lakshmi and Lord Ganesha. Bringing joy, prosperity, and authentic celebration to homes across India.
            </p>

            <div className="flex items-center gap-3 text-xs text-amber-300/80">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>100% Genuine Verified Gifts</span>
              </span>
              <span>·</span>
              <span>Audited Draw 2026</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Festival Links
            </h4>
            <ul className="space-y-2 text-xs text-amber-200/70">
              <li>
                <a href="#categories" className="hover:text-amber-300 transition-colors">
                  {t.navCategories}
                </a>
              </li>
              <li>
                <a href="#prizes" className="hover:text-amber-300 transition-colors">
                  {t.navPrizes} (49 Mega Gifts)
                </a>
              </li>
              <li>
                <button
                  onClick={onOpenResults}
                  className="hover:text-amber-300 transition-colors text-left cursor-pointer"
                >
                  {t.navResults} & Announcement
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenRules}
                  className="hover:text-amber-300 transition-colors text-left cursor-pointer"
                >
                  Official Contest Rules & Terms
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Helpline & Support */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Customer Support
            </h4>
            <ul className="space-y-2 text-xs text-amber-200/80">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-mono">{settings.contactPhone}</span>
              </li>
              <li className="flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>WhatsApp: <span className="font-mono">{settings.contactWhatsApp}</span></span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-mono">{settings.contactEmail}</span>
              </li>
              <li className="flex items-start gap-2 text-[11px] text-amber-200/60 pt-1">
                <Clock className="w-3.5 h-3.5 text-amber-400/80 shrink-0 mt-0.5" />
                <span>{lang === 'hi' ? settings.supportHoursHi || settings.supportHours : settings.supportHours}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Tier: Copyright & Discrete Administrator Access */}
        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-[11px] text-amber-200/50 gap-3">
          <div>
            © 2026 SHUB DIPAVLI Festival Organization. All Rights Reserved. Pan-India Delivery Guaranteed.
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={onOpenRules}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              Terms & Privacy
            </button>
            <span>·</span>
            {/* Discrete hidden administrator access */}
            <button
              onClick={onOpenAdmin}
              className="text-amber-300/40 hover:text-amber-300/90 transition-colors flex items-center gap-1 cursor-pointer"
              title="Restricted Staff Portal"
            >
              <Lock className="w-3 h-3" />
              <span>Officer Portal</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
