import React from 'react';
import { DiyaContest } from '../types';
import { Language } from '../lib/translations';
import { X, Sparkles, Gift, ScrollText, ArrowRight, ShieldCheck } from 'lucide-react';
import { DiyaFlame, DiyaLampSvg } from './DiwaliDecorations';

interface DiyaSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  contest: DiyaContest | null;
  lang: Language;
  onContinue: () => void;
  onViewPrizes: () => void;
  onViewRules: () => void;
}

export const DiyaSelectionModal: React.FC<DiyaSelectionModalProps> = ({
  isOpen,
  onClose,
  contest,
  lang: _lang,
  onContinue,
  onViewPrizes,
  onViewRules
}) => {
  if (!isOpen || !contest) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md rounded-2xl bg-gradient-to-b from-[#181224] via-[#0f1020] to-[#0d0e1a] border border-amber-500/50 p-6 sm:p-8 shadow-[0_0_60px_-10px_rgba(245,158,11,0.35)] text-center overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-amber-300/70 hover:text-amber-100 hover:bg-white/10 transition-colors"
          aria-label="Close popup"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-16 bg-amber-500/20 blur-xl pointer-events-none" />

        {/* Glowing Diya Artwork */}
        <div className="flex flex-col items-center justify-center pt-2 pb-3">
          <div className="relative -mb-1 z-10">
            <DiyaFlame size="md" />
          </div>
          <DiyaLampSvg className="w-16 h-12" />
        </div>

        {/* Selected Diya indicator */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>{contest.title} · Entry ₹{contest.entryFee}</span>
        </div>

        {/* Exact Required Popup Header Text */}
        <h3
          className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          Heyy Dear! ✨
        </h3>

        {/* Exact Required Popup Body Text */}
        <div className="mt-3 space-y-1 text-sm sm:text-base text-amber-100/90 leading-relaxed font-normal">
          <p className="font-semibold text-amber-300">
            Celebrate Diwali with SHUB DIPAVLI!
          </p>
          <p className="text-amber-100/80 text-xs sm:text-sm">
            Explore amazing festive prizes and participate.
          </p>
        </div>

        {/* Category highlights */}
        <div className="mt-4 p-3 rounded-xl bg-slate-950/60 border border-amber-900/40 text-left">
          <span className="text-[11px] font-bold text-amber-400 block mb-1 uppercase tracking-wider">
            Featured Gifts in this Diya ({contest.totalPrizes} Total):
          </span>
          <div className="text-xs text-amber-200/90 line-clamp-2">
            {contest.featuredPrizes.join(' · ')}
          </div>
        </div>

        {/* Three Required Action Buttons */}
        <div className="mt-6 space-y-2.5">
          {/* Button 1: Continue */}
          <button
            onClick={() => {
              onClose();
              onContinue();
            }}
            className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-lg shadow-amber-500/25 active:scale-[0.98] transition-all cursor-pointer"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            {/* Button 2: View Prizes */}
            <button
              onClick={() => {
                onClose();
                onViewPrizes();
              }}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-semibold text-amber-200 bg-amber-950/70 hover:bg-amber-900/70 border border-amber-700/50 hover:border-amber-600 transition-colors cursor-pointer"
            >
              <Gift className="w-3.5 h-3.5 text-amber-400" />
              <span>View Prizes</span>
            </button>

            {/* Button 3: Official Rules */}
            <button
              onClick={() => {
                onClose();
                onViewRules();
              }}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-semibold text-amber-200 bg-amber-950/70 hover:bg-amber-900/70 border border-amber-700/50 hover:border-amber-600 transition-colors cursor-pointer"
            >
              <ScrollText className="w-3.5 h-3.5 text-amber-400" />
              <span>Official Rules</span>
            </button>
          </div>
        </div>

        {/* Transparency note */}
        <p className="mt-4 text-[10px] text-amber-200/60 flex items-center justify-center gap-1">
          <ShieldCheck className="w-3 h-3 text-amber-400" />
          <span>Provably fair cryptographic draw · No guaranteed winning claims</span>
        </p>
      </div>
    </div>
  );
};
