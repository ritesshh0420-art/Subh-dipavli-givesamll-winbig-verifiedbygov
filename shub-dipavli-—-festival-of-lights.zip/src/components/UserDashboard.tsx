import React, { useState, useEffect } from 'react';
import { User, ContestEntry, DiyaContest } from '../types';
import { Language, translations } from '../lib/translations';
import { api, tokenStorage } from '../lib/api';
import {
  X,
  LogOut,
  Ticket,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Flame,
  Calendar,
  Image as ImageIcon
} from 'lucide-react';

interface UserDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  lang: Language;
  contests: DiyaContest[];
  resultDisplayDate: string;
  onLogout: () => void;
  onSelectDiya: (contest: DiyaContest) => void;
  onOpenContact: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  isOpen,
  onClose,
  user,
  lang,
  contests,
  resultDisplayDate,
  onLogout,
  onSelectDiya,
  onOpenContact
}) => {
  const t = translations[lang];
  const [entries, setEntries] = useState<ContestEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeReceiptModal, setActiveReceiptModal] = useState<string | null>(null);

  const fetchEntries = async () => {
    setIsLoading(true);
    try {
      const res = await api.getMyEntries();
      setEntries(res.entries || []);
    } catch (err) {
      console.error('Failed to load user entries:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchEntries();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleLogoutClick = async () => {
    try {
      await api.logout();
    } catch {
      // ignore
    }
    tokenStorage.clear();
    onLogout();
    onClose();
  };

  const verifiedCount = entries.filter(e => e.status === 'verified').length;
  const pendingCount = entries.filter(e => e.status === 'pending').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl my-auto rounded-2xl bg-[#0c0d18] border border-amber-500/50 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Dashboard Header */}
        <div className="p-5 sm:p-6 border-b border-amber-900/40 bg-gradient-to-r from-amber-950/80 via-[#0c0d18] to-amber-950/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 font-bold text-lg">
              {user.fullName ? user.fullName[0].toUpperCase() : user.username[0].toUpperCase()}
            </div>
            <div>
              <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider">
                Shubh Deepawali Dashboard
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-amber-100 flex items-center gap-2">
                <span>Welcome, {user.fullName || user.username}!</span>
              </h3>
              <span className="text-xs text-amber-200/60 font-mono">@{user.username}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleLogoutClick}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-red-300 bg-red-950/40 hover:bg-red-900/50 border border-red-800/40 transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t.logout}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-amber-300 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1">
          {/* Top KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="p-4 rounded-xl bg-slate-900/80 border border-amber-900/30 flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400">
                <Ticket className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-amber-200/70 block">Total Entries</span>
                <span className="text-xl font-bold text-amber-200 font-mono tabular-nums">{entries.length}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-amber-900/30 flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-amber-200/70 block">Approved Tickets</span>
                <span className="text-xl font-bold text-emerald-400 font-mono tabular-nums">{verifiedCount}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-amber-900/30 flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-yellow-500/10 text-yellow-400">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-amber-200/70 block">Pending Audit</span>
                <span className="text-xl font-bold text-yellow-300 font-mono tabular-nums">{pendingCount}</span>
              </div>
            </div>
          </div>

          {/* Announcement Schedule Banner */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/70 via-slate-900 to-amber-950/70 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20 text-amber-300 shrink-0">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-semibold uppercase text-amber-400 block tracking-wider">
                  Result Announcement Scheduled
                </span>
                <span
                  className="text-lg font-bold text-amber-100"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  {resultDisplayDate}
                </span>
              </div>
            </div>
            <button
              onClick={onOpenContact}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-amber-300 bg-amber-900/50 hover:bg-amber-800/60 border border-amber-700/50 transition-colors"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Contact Support</span>
            </button>
          </div>

          {/* MY ENTRIES SECTION */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-amber-200 uppercase tracking-wider flex items-center gap-2">
                <Ticket className="w-4 h-4 text-amber-400" />
                <span>My Registered Tickets & Entries ({entries.length})</span>
              </h4>
              <button
                onClick={fetchEntries}
                className="text-xs text-amber-400 hover:underline"
              >
                Refresh Status
              </button>
            </div>

            {isLoading ? (
              <div className="py-8 text-center text-xs text-amber-200/60">
                Loading your entries...
              </div>
            ) : entries.length === 0 ? (
              <div className="p-8 rounded-xl bg-slate-900/50 border border-amber-900/30 text-center space-y-3">
                <Ticket className="w-10 h-10 text-amber-400/40 mx-auto" />
                <p className="text-sm text-amber-200/70">
                  {t.noEntriesYet}
                </p>
                <div className="flex items-center justify-center gap-2 pt-1">
                  {contests.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        onClose();
                        onSelectDiya(c);
                      }}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors"
                    >
                      Enter {c.title.split('—')[0].trim()} (₹{c.entryFee})
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {entries.map((entry) => {
                  const statusColors = {
                    pending: 'bg-yellow-500/10 text-yellow-300 border-yellow-500/30',
                    verified: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
                    rejected: 'bg-red-500/10 text-red-300 border-red-500/30',
                    refunded: 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                  }[entry.status];

                  const statusLabels = {
                    pending: t.ticketStatusPending,
                    verified: t.ticketStatusVerified,
                    rejected: t.ticketStatusRejected,
                    refunded: t.ticketStatusRefunded
                  }[entry.status];

                  return (
                    <div
                      key={entry.id}
                      className="p-4 rounded-xl bg-slate-900/80 border border-amber-900/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-base sm:text-lg font-bold text-amber-300 font-mono tracking-wider">
                            {entry.ticketNumber}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusColors}`}>
                            {statusLabels}
                          </span>
                        </div>
                        <div className="text-xs text-amber-100/80 flex items-center gap-3">
                          <span className="font-semibold">{entry.contestTitle}</span>
                          <span>·</span>
                          <span className="font-mono">Contribution: ₹{entry.amount}</span>
                          <span>·</span>
                          <span className="text-amber-300/60">UTR: {entry.utrNumber}</span>
                        </div>
                        {entry.adminNotes && (
                          <div className="text-[11px] text-amber-300/90 bg-amber-950/40 px-2.5 py-1 rounded-md border border-amber-900/40">
                            <strong>Audit Note:</strong> {entry.adminNotes}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        {entry.receiptImage && (
                          <button
                            onClick={() => setActiveReceiptModal(entry.receiptImage!)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-amber-200 bg-amber-950/50 hover:bg-amber-900/50 border border-amber-800/40 transition-colors"
                          >
                            <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                            <span>Receipt</span>
                          </button>
                        )}
                        <span className="text-[11px] text-amber-300/60 font-mono">
                          {new Date(entry.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Available Categories Quick Action */}
          <div className="pt-4 border-t border-amber-900/40">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-3">
              Participate in More Diya Categories:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {contests.map((c) => (
                <div
                  key={c.id}
                  className="p-3 rounded-xl bg-slate-950 border border-amber-900/40 flex items-center justify-between"
                >
                  <div>
                    <span className="text-xs font-bold text-amber-200 block">{c.title}</span>
                    <span className="text-[11px] text-amber-300/80 font-mono">₹{c.entryFee} Entry</span>
                  </div>
                  <button
                    onClick={() => {
                      onClose();
                      onSelectDiya(c);
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors"
                  >
                    <Flame className="w-3 h-3 fill-slate-950" />
                    <span>Enter</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Receipt Image Lightbox Modal */}
        {activeReceiptModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90">
            <div className="relative max-w-lg max-h-[80vh] overflow-hidden rounded-xl border border-amber-500/50">
              <button
                onClick={() => setActiveReceiptModal(null)}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-slate-950/80 text-white hover:bg-white/20"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={activeReceiptModal}
                alt="Payment Receipt"
                className="w-full h-auto max-h-[80vh] object-contain"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
