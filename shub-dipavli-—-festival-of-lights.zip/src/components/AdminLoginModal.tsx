import React, { useState } from 'react';
import { User } from '../types';
import { api, tokenStorage } from '../lib/api';
import { X, ShieldAlert, KeyRound, UserCheck, AlertCircle } from 'lucide-react';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdminAuthSuccess: (user: User) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onAdminAuthSuccess
}) => {
  const [username, setUsername] = useState('Admin01');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const res = await api.adminLogin({
        username: username.trim(),
        password
      });

      tokenStorage.set(res.token);
      onAdminAuthSuccess(res.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify administrator credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
      <div className="relative w-full max-w-sm rounded-2xl bg-[#090b14] border border-amber-600/40 p-6 sm:p-7 shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Admin Emblem */}
        <div className="flex flex-col items-center justify-center text-center pb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-2">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h3
            className="text-lg font-bold text-amber-200"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            Festival Administration
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Restricted Executive Officer Portal
          </p>
        </div>

        {error && (
          <div className="p-2.5 mb-4 rounded-lg bg-red-950/80 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-amber-300 mb-1">
              Admin Identifier
            </label>
            <div className="relative">
              <UserCheck className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Admin01"
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-amber-100 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-amber-300 mb-1">
              Security Key / Password
            </label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-amber-100 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-900/80 border border-amber-900/40 text-[10px] text-slate-400 leading-tight">
            Protected endpoint with server-side role authorization. Initial seed password: <code className="text-amber-300 font-mono">Admin@Diwali2026!</code>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 transition-all cursor-pointer shadow-md shadow-amber-500/20"
          >
            {isLoading ? 'Authenticating...' : 'Enter Admin Dashboard'}
          </button>
        </form>
      </div>
    </div>
  );
};
