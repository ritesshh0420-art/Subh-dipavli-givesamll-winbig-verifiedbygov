import React from 'react';
import { WinnerRecord } from '../types';
import { Language } from '../lib/translations';
import { X, Award, ShieldCheck, CheckCircle2, Calendar, FileText } from 'lucide-react';

interface ResultsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isResultPublished: boolean;
  announcementDate: string;
  displayDateText: string;
  winners: WinnerRecord[];
  lang: Language;
}

export const ResultsModal: React.FC<ResultsModalProps> = ({
  isOpen,
  onClose,
  isResultPublished,
  announcementDate: _announcementDate,
  displayDateText,
  winners,
  lang: _lang
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl my-auto rounded-2xl bg-[#0c0d18] border border-amber-500/50 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-amber-900/40 bg-gradient-to-r from-amber-950/80 via-[#0c0d18] to-amber-950/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Audited Transparency & Result Ledger</span>
              </div>
              <h3
                className="text-lg sm:text-xl font-bold text-amber-100"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Official Festive Lucky Draw Announcement
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-amber-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1">
          {/* Certificate Banner */}
          <div className="p-4 sm:p-5 rounded-xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/60 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 block mb-1">
                Official Result Announcement Date
              </span>
              <div
                className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                {displayDateText || '7 NOVEMBER 2026'}
              </div>
              <p className="text-xs text-amber-200/70 mt-1">
                Conducting Authority: Festival Lucky Draw Committee & Independent Audit Observers
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
                  isResultPublished
                    ? 'bg-emerald-950 border border-emerald-500/50 text-emerald-300'
                    : 'bg-amber-950 border border-amber-500/50 text-amber-300'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isResultPublished ? 'Official Results Certified' : 'Draw Scheduled in Queue'}</span>
              </span>
            </div>
          </div>

          {/* If Published: Showcase Winners Table */}
          {isResultPublished && winners.length > 0 ? (
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-amber-300 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span>Official Published Winners ({winners.length})</span>
              </h4>

              <div className="rounded-xl border border-amber-900/30 overflow-hidden bg-slate-900/60">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-amber-100/90">
                    <thead className="bg-slate-950/80 text-[11px] font-bold uppercase tracking-wider text-amber-400 border-b border-amber-900/40">
                      <tr>
                        <th className="p-3">Winning Ticket</th>
                        <th className="p-3">Prize Item</th>
                        <th className="p-3">Diya Category</th>
                        <th className="p-3">Winner (Privacy Masked)</th>
                        <th className="p-3">Cryptographic Audit Hash</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 font-sans">
                      {winners.map((winner) => (
                        <tr key={winner.id} className="hover:bg-slate-900/40">
                          <td className="p-3 font-mono font-bold text-amber-300 text-sm">
                            {winner.ticketNumber}
                          </td>
                          <td className="p-3 font-semibold text-amber-100">
                            {winner.prizeName}
                          </td>
                          <td className="p-3 text-amber-400">
                            {winner.contestTitle}
                          </td>
                          <td className="p-3 font-mono text-amber-200">
                            {winner.winnerUsername} ({winner.winnerCity})
                          </td>
                          <td className="p-3 font-mono text-[11px] text-amber-300/80">
                            {winner.drawAuditHash}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            /* If Pending / Not yet published */
            <div className="p-8 rounded-xl bg-slate-900/50 border border-amber-900/30 text-center space-y-3">
              <Calendar className="w-10 h-10 text-amber-400/50 mx-auto" />
              <h4 className="text-base font-bold text-amber-200">
                Official Draw Will Be Published on {displayDateText}
              </h4>
              <p className="text-xs text-amber-200/70 max-w-lg mx-auto leading-relaxed">
                Tickets are currently undergoing multi-point payment and UTR verification by the audit desk.
                All verified tickets will be placed into the cryptographic random draw hopper at the scheduled time.
                Check back here to view the published results and audit certificates.
              </p>
            </div>
          )}

          {/* Selection Methodology & Integrity Statement */}
          <div className="p-4 rounded-xl bg-slate-950 border border-amber-900/40 space-y-2 text-xs text-amber-200/80">
            <div className="flex items-center gap-1.5 font-bold text-amber-300 uppercase tracking-wider text-[11px]">
              <FileText className="w-3.5 h-3.5" />
              <span>Selection Integrity & Privacy Notice</span>
            </div>
            <p className="leading-relaxed">
              In strict adherence to consumer transparency and Indian legal regulations, participant selection is conducted through a provably fair random selection algorithm. Winner contact numbers are strictly masked on public channels for privacy protection. Verified winners are contacted personally via telephone and postal dispatch for prize handover.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-amber-900/40 flex items-center justify-between text-xs text-amber-200/60">
          <span>SHUB DIPAVLI Audit Board</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
