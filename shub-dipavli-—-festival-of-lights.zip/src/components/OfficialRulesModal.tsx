import React, { useState } from 'react';
import { SiteSettings } from '../types';
import { Language } from '../lib/translations';
import { X, ScrollText, ShieldCheck, Lock, HelpCircle } from 'lucide-react';

interface OfficialRulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SiteSettings;
  lang: Language;
}

export const OfficialRulesModal: React.FC<OfficialRulesModalProps> = ({
  isOpen,
  onClose,
  settings,
  lang
}) => {
  const [tab, setTab] = useState<'rules' | 'privacy' | 'fairplay'>('rules');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl my-auto rounded-2xl bg-[#0c0d18] border border-amber-500/50 shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="p-5 border-b border-amber-900/40 bg-gradient-to-r from-amber-950/80 via-[#0c0d18] to-amber-950/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300">
              <ScrollText className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Compliance & Legal Governance
              </div>
              <h3
                className="text-lg sm:text-xl font-bold text-amber-100"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Official Festival Rules & Fair Play Terms
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-amber-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Strip */}
        <div className="px-5 py-2 border-b border-white/5 bg-slate-950/60 flex items-center gap-2 text-xs font-semibold">
          <button
            onClick={() => setTab('rules')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              tab === 'rules'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            Official Contest Rules
          </button>
          <button
            onClick={() => setTab('fairplay')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              tab === 'fairplay'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            Transparent Draw Process
          </button>
          <button
            onClick={() => setTab('privacy')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              tab === 'privacy'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            Privacy & Data Security
          </button>
        </div>

        {/* Content Pane */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs text-amber-100/90 leading-relaxed">
          {tab === 'rules' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-800/40 flex items-center gap-2.5 text-amber-300 font-semibold">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Eligibility: Open to all Indian citizens aged 18 years or above.</span>
              </div>

              <div className="whitespace-pre-line text-amber-100/90">
                {lang === 'hi'
                  ? settings.officialRulesHi || settings.officialRules
                  : settings.officialRules}
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-amber-900/40 text-amber-200/80 space-y-2">
                <strong className="block text-amber-300">Contest Schedule & Key Dates:</strong>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Contest Participation Period: Active through Diwali Festive Season 2026.</li>
                  <li>Official Result Announcement: <strong>{settings.resultDisplayDate}</strong>.</li>
                  <li>Prize Claims & Dispatch: Commences within 7 business days following official announcement.</li>
                </ul>
              </div>
            </div>
          )}

          {tab === 'fairplay' && (
            <div className="space-y-3.5">
              <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-800/40 flex items-center gap-2.5 text-amber-300 font-semibold">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Provably Fair Cryptographic Random Number Generation</span>
              </div>

              <p>
                To eliminate human bias or tampering, all verified participant tickets are aggregated into the official festival ledger. During the scheduled draw event:
              </p>

              <ol className="list-decimal pl-5 space-y-2 text-amber-200/90">
                <li>
                  <strong>Ledger Seal:</strong> The ticket database is frozen at the cutoff timestamp, creating an immutable list of entries.
                </li>
                <li>
                  <strong>Fisher-Yates Cryptographic Shuffle:</strong> A secure hardware-random pseudo-random generator is executed to determine winner ticket numbers.
                </li>
                <li>
                  <strong>Cryptographic Audit Hash:</strong> Each winning ticket receives an irreversible SHA-256 audit digest that is published alongside the prize.
                </li>
                <li>
                  <strong>No Guaranteed Claims:</strong> Participation does not guarantee winning. Winning chance corresponds strictly to the number of legitimate verified entries held.
                </li>
              </ol>
            </div>
          )}

          {tab === 'privacy' && (
            <div className="space-y-3.5">
              <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-800/40 flex items-center gap-2.5 text-amber-300 font-semibold">
                <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Encrypted Data Storage & Masked Public Announcements</span>
              </div>

              <div className="whitespace-pre-line text-amber-100/90">
                {settings.privacyPolicy}
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-amber-900/40 space-y-1 text-amber-200/80">
                <strong className="block text-amber-300">Grievance & Support Officer:</strong>
                <div>Email: <span className="font-mono text-amber-400">{settings.contactEmail}</span></div>
                <div>Helpline: <span className="font-mono text-amber-400">{settings.contactPhone}</span></div>
                <div>Hours: {settings.supportHours}</div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-amber-900/40 flex items-center justify-between text-xs text-amber-200/60">
          <span>SHUB DIPAVLI Trust Board</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
