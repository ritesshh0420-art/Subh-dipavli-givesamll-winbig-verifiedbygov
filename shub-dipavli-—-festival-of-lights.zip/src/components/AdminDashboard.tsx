import React, { useState, useEffect } from 'react';
import {
  User,
  DiyaContest,
  PrizeItem,
  ContestEntry,
  PaymentConfig,
  SiteSettings,
  WinnerRecord,
  AdminStats
} from '../types';
import { api, tokenStorage } from '../lib/api';
import {
  X,
  LogOut,
  BarChart3,
  Users,
  Gift,
  CreditCard,
  Settings,
  Award,
  FileText,
  Search,
  CheckCircle2,
  XCircle,
  Plus,
  Trash2,
  Edit2,
  Image as ImageIcon,
  ShieldCheck,
  AlertCircle,
  Check,
  RotateCcw
} from 'lucide-react';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  adminUser: User;
  onLogout: () => void;
  onDataUpdated?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  adminUser,
  onLogout,
  onDataUpdated
}) => {
  type AdminTab = 'overview' | 'users' | 'prizes' | 'payments' | 'results' | 'content' | 'audit';
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  const [stats, setStats] = useState<AdminStats | null>(null);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [entriesList, setEntriesList] = useState<ContestEntry[]>([]);
  const [prizesList, setPrizesList] = useState<PrizeItem[]>([]);
  const [contestsList, setContestsList] = useState<DiyaContest[]>([]);
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig | null>(null);
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);
  const [winnersList, setWinnersList] = useState<WinnerRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  const [isLoading, setIsLoading] = useState(false);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Filters & State
  const [userSearch, setUserSearch] = useState('');
  const [entryStatusFilter, setEntryStatusFilter] = useState('all');
  const [prizeContestFilter, setPrizeContestFilter] = useState('all');
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);

  // Prize Edit/Add Modal State
  const [editingPrize, setEditingPrize] = useState<Partial<PrizeItem> | null>(null);
  const [isAddPrizeOpen, setIsAddPrizeOpen] = useState(false);

  // User Reset Password State
  const [resetPassUser, setResetPassUser] = useState<{ id: string; username: string } | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');

  const loadAllData = async () => {
    setIsLoading(true);
    try {
      const [
        statsRes,
        usersRes,
        entriesRes,
        prizesRes,
        contestsRes,
        paymentRes,
        settingsRes,
        resultsRes,
        auditRes
      ] = await Promise.all([
        api.getAdminStats(),
        api.getAdminUsers(),
        api.getAdminEntries(),
        api.getPrizes(),
        api.getContests(),
        api.getPaymentConfig(),
        api.getSettings(),
        api.getResults(),
        api.getAuditLogs()
      ]);

      setStats(statsRes.stats);
      setUsersList(usersRes.users);
      setEntriesList(entriesRes.entries);
      setPrizesList(prizesRes.prizes);
      setContestsList(contestsRes.contests);
      setPaymentConfig(paymentRes.paymentConfig);
      setSiteSettings(settingsRes.settings);
      setWinnersList(resultsRes.winners);
      setAuditLogs(auditRes.logs);
    } catch (err: any) {
      console.error('Failed to load admin dashboard data:', err);
      setActionMessage({ type: 'error', text: err.message || 'Failed to sync admin data' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadAllData();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const showToast = (type: 'success' | 'error', text: string) => {
    setActionMessage({ type, text });
    setTimeout(() => setActionMessage(null), 4000);
  };

  // Toggle User Active/Suspend
  const handleToggleUser = async (userId: string, currentStatus: boolean) => {
    try {
      await api.toggleUserStatus(userId, !currentStatus);
      showToast('success', `User ${!currentStatus ? 'activated' : 'suspended'} successfully.`);
      loadAllData();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Admin Reset User Password
  const handleAdminResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPassUser || !newPasswordInput) return;
    try {
      await api.adminResetPassword(resetPassUser.id, newPasswordInput);
      showToast('success', `Password for ${resetPassUser.username} updated.`);
      setResetPassUser(null);
      setNewPasswordInput('');
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Verify / Reject / Refund Entry
  const handleUpdateEntry = async (entryId: string, status: string, notes?: string) => {
    try {
      await api.updateEntryStatus(entryId, status, notes);
      showToast('success', `Entry status updated to ${status}.`);
      loadAllData();
      if (onDataUpdated) onDataUpdated();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Save Prize (Add or Update)
  const handleSavePrize = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPrize) return;

    try {
      if (editingPrize.id) {
        await api.updatePrize(editingPrize.id, editingPrize);
        showToast('success', 'Prize details updated.');
      } else {
        await api.addPrize(editingPrize);
        showToast('success', 'New prize added.');
      }
      setEditingPrize(null);
      setIsAddPrizeOpen(false);
      loadAllData();
      if (onDataUpdated) onDataUpdated();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Delete Prize
  const handleDeletePrize = async (prizeId: string, name: string) => {
    if (!window.confirm(`Are you sure you want to remove "${name}" from the prize catalog?`)) {
      return;
    }
    try {
      await api.deletePrize(prizeId);
      showToast('success', `Prize "${name}" removed.`);
      loadAllData();
      if (onDataUpdated) onDataUpdated();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Update Payment Config
  const handleSavePaymentConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentConfig) return;
    try {
      await api.updatePaymentConfig(paymentConfig);
      showToast('success', 'Payment and UPI details updated successfully.');
      loadAllData();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Update Site Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!siteSettings) return;
    try {
      await api.updateSettings(siteSettings);
      showToast('success', 'Website settings and content saved.');
      loadAllData();
      if (onDataUpdated) onDataUpdated();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Conduct Cryptographic Draw
  const handleConductDraw = async () => {
    const verifiedCount = entriesList.filter(e => e.status === 'verified').length;
    if (verifiedCount === 0) {
      showToast('error', 'Cannot conduct draw: No verified entries found. Please approve payments first.');
      return;
    }

    if (!window.confirm(`Conduct transparent cryptographic draw across all ${verifiedCount} verified participant tickets?`)) {
      return;
    }

    try {
      const res = await api.conductDraw();
      showToast('success', `Draw completed! ${res.count} winners generated with audit hashes.`);
      loadAllData();
      if (onDataUpdated) onDataUpdated();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Toggle Results Published State
  const handleTogglePublishResults = async () => {
    if (!siteSettings) return;
    const newState = !siteSettings.isResultPublished;
    try {
      await api.publishResults(newState);
      showToast('success', `Official results are now ${newState ? 'PUBLISHED PUBLIC' : 'HIDDEN'}.`);
      loadAllData();
      if (onDataUpdated) onDataUpdated();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md">
      <div className="relative w-full max-w-6xl h-[94vh] rounded-2xl bg-[#0a0b14] border border-amber-600/50 shadow-2xl flex flex-col overflow-hidden">
        {/* Admin Navigation Bar */}
        <div className="p-4 sm:p-5 border-b border-amber-900/40 bg-gradient-to-r from-amber-950/90 via-[#0a0b14] to-amber-950/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 text-slate-950 flex items-center justify-center font-black">
              👑
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-amber-400 tracking-widest flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Executive Administrative Panel</span>
              </div>
              <h2
                className="text-base sm:text-lg font-bold text-amber-100"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                SHUB DIPAVLI — Management Console
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                tokenStorage.clear();
                onLogout();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg text-red-300 bg-red-950/40 hover:bg-red-900/50 border border-red-800/40 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Admin Logout</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toast Action Notice */}
        {actionMessage && (
          <div
            className={`px-4 py-2 text-xs font-semibold flex items-center gap-2 transition-all ${
              actionMessage.type === 'success'
                ? 'bg-emerald-950/90 text-emerald-300 border-b border-emerald-500/40'
                : 'bg-red-950/90 text-red-300 border-b border-red-500/40'
            }`}
          >
            {actionMessage.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{actionMessage.text}</span>
          </div>
        )}

        {/* Tab Controls */}
        <div className="px-4 py-2 border-b border-white/5 bg-slate-950/60 flex items-center gap-2 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'overview', label: 'Dashboard Overview', icon: BarChart3 },
            { id: 'users', label: 'User Accounts', icon: Users },
            { id: 'payments', label: 'Payment & UTR Verification', icon: CreditCard },
            { id: 'prizes', label: 'Contests & 49 Prizes', icon: Gift },
            { id: 'results', label: 'Result & Draw Conduct', icon: Award },
            { id: 'content', label: 'Content & Branding', icon: Settings },
            { id: 'audit', label: 'Audit Trail', icon: FileText }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as AdminTab)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                    : 'text-amber-200/70 hover:text-amber-100 hover:bg-amber-950/30'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Panes */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-[#0a0b14]">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Metrics Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
                <div className="p-4 rounded-xl bg-slate-900/80 border border-amber-900/30">
                  <span className="text-xs text-amber-300/70 block">Registered Users</span>
                  <span className="text-2xl font-bold text-amber-200 font-mono tabular-nums">{stats?.totalUsers || 0}</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-900/80 border border-amber-900/30">
                  <span className="text-xs text-amber-300/70 block">Total Entries</span>
                  <span className="text-2xl font-bold text-amber-200 font-mono tabular-nums">{stats?.totalEntries || 0}</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-900/80 border border-yellow-500/30">
                  <span className="text-xs text-yellow-300/70 block">Pending Audit</span>
                  <span className="text-2xl font-bold text-yellow-400 font-mono tabular-nums">{stats?.pendingEntries || 0}</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-900/80 border border-emerald-500/30">
                  <span className="text-xs text-emerald-300/70 block">Approved Tickets</span>
                  <span className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">{stats?.verifiedEntries || 0}</span>
                </div>
                <div className="col-span-2 lg:col-span-1 p-4 rounded-xl bg-slate-900/80 border border-amber-500/30">
                  <span className="text-xs text-amber-300/70 block">Verified Revenue</span>
                  <span className="text-2xl font-bold text-amber-300 font-mono tabular-nums">₹{stats?.totalCollected?.toLocaleString('en-IN') || 0}</span>
                </div>
              </div>

              {/* Status and Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-5 rounded-xl bg-slate-900/60 border border-amber-900/40 space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                    <Award className="w-4 h-4" />
                    <span>Contest Operation Status</span>
                  </h4>
                  <div className="space-y-2 text-xs text-amber-100/80">
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span>Diya 1 (₹199):</span>
                      <strong className="text-emerald-400">Active · 12 Prizes</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span>Diya 2 (₹499):</span>
                      <strong className="text-emerald-400">Active · 17 Prizes</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span>Diya 3 (₹999):</span>
                      <strong className="text-emerald-400">Active · 20 Prizes</strong>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Scheduled Result Date:</span>
                      <strong className="text-amber-300 font-mono">{siteSettings?.resultDisplayDate}</strong>
                    </div>
                  </div>
                </div>

                <div className="p-5 rounded-xl bg-slate-900/60 border border-amber-900/40 space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    <span>Recent Administrative Logs</span>
                  </h4>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto text-xs text-amber-200/80">
                    {auditLogs.slice(0, 5).map((log) => (
                      <div key={log.id} className="p-1.5 rounded bg-slate-950/60 border border-white/5 text-[11px]">
                        <span className="text-amber-400 font-mono font-bold">[{log.action}]</span>{' '}
                        <span>{log.details}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: USER MANAGEMENT */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search users by name, username, phone..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-900 border border-amber-800/40 text-amber-100 placeholder:text-amber-400/40 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div className="text-xs text-amber-200/70">
                  Total Registered Users: <strong>{usersList.length}</strong>
                </div>
              </div>

              <div className="rounded-xl border border-amber-900/30 overflow-hidden bg-slate-900/60">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-amber-100/90">
                    <thead className="bg-slate-950/80 text-[11px] font-bold uppercase tracking-wider text-amber-400 border-b border-amber-900/40">
                      <tr>
                        <th className="p-3">User</th>
                        <th className="p-3">Consent Phone</th>
                        <th className="p-3">Registered Date</th>
                        <th className="p-3">Contest Entries</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {usersList
                        .filter(
                          (u) =>
                            !userSearch ||
                            u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
                            u.fullName.toLowerCase().includes(userSearch.toLowerCase()) ||
                            (u.phone && u.phone.includes(userSearch))
                        )
                        .map((u) => (
                          <tr key={u.id} className="hover:bg-slate-900/40 transition-colors">
                            <td className="p-3">
                              <strong className="block text-amber-200 font-semibold">{u.fullName || u.username}</strong>
                              <span className="text-[11px] text-amber-400/70 font-mono">@{u.username}</span>
                            </td>
                            <td className="p-3 font-mono text-amber-300/80">{u.phone || 'Not Provided'}</td>
                            <td className="p-3 text-amber-200/70">{new Date(u.createdAt).toLocaleDateString()}</td>
                            <td className="p-3 font-mono">
                              <span className="font-bold text-amber-300">{u.entriesCount}</span> entries (
                              <span className="text-emerald-400">{u.verifiedEntriesCount} approved</span>)
                            </td>
                            <td className="p-3">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  u.isActive
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                    : 'bg-red-500/10 text-red-400 border border-red-500/30'
                                }`}
                              >
                                {u.isActive ? 'Active' : 'Suspended'}
                              </span>
                            </td>
                            <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                              <button
                                onClick={() => setResetPassUser({ id: u.id, username: u.username })}
                                className="px-2 py-1 rounded bg-amber-950/60 text-amber-300 hover:bg-amber-900/60 border border-amber-800/40 text-[11px] font-medium transition-colors"
                              >
                                Reset Pass
                              </button>
                              <button
                                onClick={() => handleToggleUser(u.id, u.isActive)}
                                className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                                  u.isActive
                                    ? 'bg-red-950/60 text-red-300 hover:bg-red-900/60 border border-red-800/40'
                                    : 'bg-emerald-950/60 text-emerald-300 hover:bg-emerald-900/60 border border-emerald-800/40'
                                }`}
                              >
                                {u.isActive ? 'Suspend' : 'Reactivate'}
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PAYMENT & UTR VERIFICATION */}
          {activeTab === 'payments' && (
            <div className="space-y-6">
              {/* Top: Edit UPI and Bank Config Section */}
              <div className="p-5 rounded-xl bg-slate-900/60 border border-amber-900/40 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                    <CreditCard className="w-4 h-4" />
                    <span>UPI & Bank Account Settings</span>
                  </h4>
                  {paymentConfig && (
                    <label className="flex items-center gap-2 text-xs text-amber-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={paymentConfig.isEnabled}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, isEnabled: e.target.checked })}
                        className="rounded border-amber-700 text-amber-500"
                      />
                      <span>Enable Customer Payments</span>
                    </label>
                  )}
                </div>

                {paymentConfig && (
                  <form onSubmit={handleSavePaymentConfig} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-amber-300 mb-1">Official UPI ID</label>
                      <input
                        type="text"
                        value={paymentConfig.upiId}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, upiId: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-amber-300 mb-1">UPI QR Code URL</label>
                      <input
                        type="text"
                        value={paymentConfig.upiQrUrl}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, upiQrUrl: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-amber-300 mb-1">Account Holder Name</label>
                      <input
                        type="text"
                        value={paymentConfig.accountHolderName}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, accountHolderName: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-amber-300 mb-1">Bank Name</label>
                      <input
                        type="text"
                        value={paymentConfig.bankName}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, bankName: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-amber-300 mb-1">Account Number</label>
                      <input
                        type="text"
                        value={paymentConfig.accountNumber}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, accountNumber: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-amber-300 mb-1">IFSC Code</label>
                      <input
                        type="text"
                        value={paymentConfig.ifscCode}
                        onChange={(e) => setPaymentConfig({ ...paymentConfig, ifscCode: e.target.value })}
                        className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100 font-mono"
                      />
                    </div>
                    <div className="sm:col-span-3 flex justify-end">
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-lg text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors"
                      >
                        Update Payment Gateway Settings
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Bottom: Entries Verification Queue */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Participant Entries & Ledger Verification ({entriesList.length})
                  </h4>

                  <div className="flex items-center gap-2">
                    <select
                      value={entryStatusFilter}
                      onChange={(e) => setEntryStatusFilter(e.target.value)}
                      className="px-3 py-1.5 text-xs rounded-lg bg-slate-900 border border-amber-800/40 text-amber-100"
                    >
                      <option value="all">All Statuses</option>
                      <option value="pending">Pending Audit</option>
                      <option value="verified">Approved & Valid</option>
                      <option value="rejected">Rejected</option>
                      <option value="refunded">Refunded</option>
                    </select>
                  </div>
                </div>

                <div className="rounded-xl border border-amber-900/30 overflow-hidden bg-slate-900/60">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-amber-100/90">
                      <thead className="bg-slate-950/80 text-[11px] font-bold uppercase tracking-wider text-amber-400 border-b border-amber-900/40">
                        <tr>
                          <th className="p-3">Ticket / Date</th>
                          <th className="p-3">Participant</th>
                          <th className="p-3">Category / Fee</th>
                          <th className="p-3">Transaction UTR</th>
                          <th className="p-3">Screenshot</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Audit Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {entriesList
                          .filter((e) => entryStatusFilter === 'all' || e.status === entryStatusFilter)
                          .map((entry) => (
                            <tr key={entry.id} className="hover:bg-slate-900/40 transition-colors">
                              <td className="p-3">
                                <span className="font-bold text-amber-300 font-mono block text-sm">
                                  {entry.ticketNumber}
                                </span>
                                <span className="text-[10px] text-amber-200/60 font-mono">
                                  {new Date(entry.createdAt).toLocaleDateString()}
                                </span>
                              </td>
                              <td className="p-3">
                                <strong className="block text-amber-200">{entry.fullName}</strong>
                                <span className="text-[11px] text-amber-400/80 font-mono">{entry.phone}</span>
                              </td>
                              <td className="p-3">
                                <span className="block font-semibold">{entry.contestTitle}</span>
                                <strong className="text-amber-300 font-mono">₹{entry.amount}</strong>
                              </td>
                              <td className="p-3 font-mono font-bold text-amber-400">
                                {entry.utrNumber}
                              </td>
                              <td className="p-3">
                                {entry.receiptImage ? (
                                  <button
                                    onClick={() => setSelectedReceipt(entry.receiptImage!)}
                                    className="flex items-center gap-1 px-2 py-1 rounded bg-amber-950/60 text-amber-300 hover:bg-amber-900/60 border border-amber-800/40 text-[10px] font-semibold"
                                  >
                                    <ImageIcon className="w-3 h-3 text-amber-400" />
                                    <span>View Image</span>
                                  </button>
                                ) : (
                                  <span className="text-[10px] text-slate-500">None</span>
                                )}
                              </td>
                              <td className="p-3">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    entry.status === 'verified'
                                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                      : entry.status === 'pending'
                                      ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/30'
                                      : entry.status === 'rejected'
                                      ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                                      : 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                                  }`}
                                >
                                  {entry.status}
                                </span>
                              </td>
                              <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                                {entry.status !== 'verified' && (
                                  <button
                                    onClick={() => handleUpdateEntry(entry.id, 'verified', 'UTR matched bank statement')}
                                    className="px-2 py-1 rounded bg-emerald-950/80 text-emerald-300 hover:bg-emerald-900 border border-emerald-700/60 text-[11px] font-bold transition-colors"
                                  >
                                    Approve Ticket
                                  </button>
                                )}
                                {entry.status !== 'rejected' && (
                                  <button
                                    onClick={() => handleUpdateEntry(entry.id, 'rejected', 'UTR unverified')}
                                    className="px-2 py-1 rounded bg-red-950/80 text-red-300 hover:bg-red-900 border border-red-700/60 text-[11px] font-medium transition-colors"
                                  >
                                    Reject
                                  </button>
                                )}
                                <button
                                  onClick={() => handleUpdateEntry(entry.id, 'refunded', 'Refund processed to source')}
                                  className="px-2 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-600 text-[11px] font-medium transition-colors"
                                >
                                  Record Refund
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CONTESTS & 49 PRIZES */}
          {activeTab === 'prizes' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <select
                    value={prizeContestFilter}
                    onChange={(e) => setPrizeContestFilter(e.target.value)}
                    className="px-3 py-1.5 text-xs rounded-lg bg-slate-900 border border-amber-800/40 text-amber-100"
                  >
                    <option value="all">All Diya Categories (49 Prizes)</option>
                    <option value="diya-1">Diya 1 (12 Prizes · ₹199)</option>
                    <option value="diya-2">Diya 2 (17 Prizes · ₹499)</option>
                    <option value="diya-3">Diya 3 (20 Prizes · ₹999)</option>
                  </select>
                </div>

                <button
                  onClick={() => {
                    setEditingPrize({
                      contestId: 'diya-1',
                      category: 'lifestyle',
                      marketValue: '₹10,000',
                      isVerified: true
                    });
                    setIsAddPrizeOpen(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New Prize Item</span>
                </button>
              </div>

              <div className="rounded-xl border border-amber-900/30 overflow-hidden bg-slate-900/60">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-amber-100/90">
                    <thead className="bg-slate-950/80 text-[11px] font-bold uppercase tracking-wider text-amber-400 border-b border-amber-900/40">
                      <tr>
                        <th className="p-3">#</th>
                        <th className="p-3">Thumbnail</th>
                        <th className="p-3">Prize Name & Hindi</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Market Value</th>
                        <th className="p-3">Diya</th>
                        <th className="p-3">Verified</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {prizesList
                        .filter((p) => prizeContestFilter === 'all' || p.contestId === prizeContestFilter)
                        .map((prize) => (
                          <tr key={prize.id} className="hover:bg-slate-900/40 transition-colors">
                            <td className="p-3 font-mono text-amber-400 font-bold">{prize.orderNumber}</td>
                            <td className="p-3">
                              <img
                                src={prize.imageUrl}
                                alt={prize.name}
                                className="w-10 h-10 object-cover rounded-lg border border-amber-900/40 bg-slate-950"
                                referrerPolicy="no-referrer"
                              />
                            </td>
                            <td className="p-3">
                              <strong className="block text-amber-100">{prize.name}</strong>
                              <span className="text-[11px] text-amber-300/80">{prize.nameHi}</span>
                            </td>
                            <td className="p-3 uppercase text-[10px] text-amber-400/80 font-bold">{prize.category}</td>
                            <td className="p-3 font-mono font-semibold text-amber-300">{prize.marketValue}</td>
                            <td className="p-3 text-xs uppercase font-semibold text-amber-300">{prize.contestId}</td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                                Verified Available
                              </span>
                            </td>
                            <td className="p-3 text-right space-x-1 whitespace-nowrap">
                              <button
                                onClick={() => {
                                  setEditingPrize({ ...prize });
                                  setIsAddPrizeOpen(true);
                                }}
                                className="p-1.5 rounded bg-amber-950/60 text-amber-300 hover:bg-amber-900/60 border border-amber-800/40 transition-colors"
                                title="Edit Prize"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeletePrize(prize.id, prize.name)}
                                className="p-1.5 rounded bg-red-950/60 text-red-300 hover:bg-red-900/60 border border-red-800/40 transition-colors"
                                title="Delete Prize"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: RESULT & DRAW CONDUCT */}
          {activeTab === 'results' && (
            <div className="space-y-6">
              <div className="p-5 rounded-xl bg-slate-900/60 border border-amber-900/40 space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                      <Award className="w-4 h-4" />
                      <span>Transparent Cryptographic Lucky Draw Engine</span>
                    </h4>
                    <p className="text-xs text-amber-200/70 mt-1 max-w-xl">
                      The draw utilizes a SHA-256 Fisher-Yates cryptographically seeded algorithm across verified tickets to allocate winners for each Diya category.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleConductDraw}
                      className="px-4 py-2 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 shadow-md transition-all flex items-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Conduct Transparent Draw</span>
                    </button>

                    <button
                      onClick={handleTogglePublishResults}
                      className={`px-4 py-2 rounded-xl font-bold text-xs transition-all ${
                        siteSettings?.isResultPublished
                          ? 'bg-red-500 hover:bg-red-400 text-white'
                          : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                      }`}
                    >
                      {siteSettings?.isResultPublished ? 'Unpublish Results' : 'Publish Results to Public'}
                    </button>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-xs text-amber-200/80 gap-2">
                  <span>
                    Current Result Date: <strong className="text-amber-300">{siteSettings?.resultDisplayDate}</strong>
                  </span>
                  <span>
                    Public Status:{' '}
                    <strong className={siteSettings?.isResultPublished ? 'text-emerald-400' : 'text-yellow-400'}>
                      {siteSettings?.isResultPublished ? 'LIVE & PUBLISHED' : 'SCHEDULED / UNPUBLISHED'}
                    </strong>
                  </span>
                </div>
              </div>

              {/* Winners Table */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Allocated Winners ({winnersList.length})
                </h4>

                {winnersList.length === 0 ? (
                  <div className="p-8 rounded-xl bg-slate-900/50 border border-amber-900/30 text-center text-xs text-amber-200/70">
                    No winners drawn yet. Approve participants and click "Conduct Transparent Draw" to generate audited winners.
                  </div>
                ) : (
                  <div className="rounded-xl border border-amber-900/30 overflow-hidden bg-slate-900/60">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs text-amber-100/90">
                        <thead className="bg-slate-950/80 text-[11px] font-bold uppercase tracking-wider text-amber-400 border-b border-amber-900/40">
                          <tr>
                            <th className="p-3">Ticket</th>
                            <th className="p-3">Prize Allocated</th>
                            <th className="p-3">Winner (Privacy Masked)</th>
                            <th className="p-3">Contest</th>
                            <th className="p-3">Draw Audit Hash</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {winnersList.map((w) => (
                            <tr key={w.id} className="hover:bg-slate-900/40">
                              <td className="p-3 font-mono font-bold text-amber-300">{w.ticketNumber}</td>
                              <td className="p-3 font-semibold text-amber-100">{w.prizeName}</td>
                              <td className="p-3 font-mono">{w.winnerUsername} ({w.winnerCity})</td>
                              <td className="p-3 text-amber-400">{w.contestTitle}</td>
                              <td className="p-3 font-mono text-[11px] text-amber-300/80">{w.drawAuditHash}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: CONTENT & BRANDING */}
          {activeTab === 'content' && siteSettings && (
            <form onSubmit={handleSaveSettings} className="space-y-5">
              <div className="p-5 rounded-xl bg-slate-900/60 border border-amber-900/40 space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Branding & Homepage Texts
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Website Title</label>
                    <input
                      type="text"
                      value={siteSettings.websiteTitle}
                      onChange={(e) => setSiteSettings({ ...siteSettings, websiteTitle: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Result Display Date</label>
                    <input
                      type="text"
                      value={siteSettings.resultDisplayDate}
                      onChange={(e) => setSiteSettings({ ...siteSettings, resultDisplayDate: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100 font-mono font-bold"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Hero Headline</label>
                    <input
                      type="text"
                      value={siteSettings.heroHeadline}
                      onChange={(e) => setSiteSettings({ ...siteSettings, heroHeadline: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Hero Headline (Hindi)</label>
                    <input
                      type="text"
                      value={siteSettings.heroHeadlineHi}
                      onChange={(e) => setSiteSettings({ ...siteSettings, heroHeadlineHi: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Hero Subheadline</label>
                    <textarea
                      rows={2}
                      value={siteSettings.heroSubheadline}
                      onChange={(e) => setSiteSettings({ ...siteSettings, heroSubheadline: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                    />
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-xl bg-slate-900/60 border border-amber-900/40 space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Contact & Support Information
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Helpline Phone</label>
                    <input
                      type="text"
                      value={siteSettings.contactPhone}
                      onChange={(e) => setSiteSettings({ ...siteSettings, contactPhone: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">WhatsApp Helpline</label>
                    <input
                      type="text"
                      value={siteSettings.contactWhatsApp}
                      onChange={(e) => setSiteSettings({ ...siteSettings, contactWhatsApp: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Support Email</label>
                    <input
                      type="email"
                      value={siteSettings.contactEmail}
                      onChange={(e) => setSiteSettings({ ...siteSettings, contactEmail: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-amber-300 mb-1">Support Hours</label>
                    <input
                      type="text"
                      value={siteSettings.supportHours}
                      onChange={(e) => setSiteSettings({ ...siteSettings, supportHours: e.target.value })}
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl font-bold text-xs text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors cursor-pointer"
                >
                  Save Website Content & Settings
                </button>
              </div>
            </form>
          )}

          {/* TAB 7: AUDIT TRAIL */}
          {activeTab === 'audit' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Audited System Log ({auditLogs.length} Entries)
              </h4>
              <div className="rounded-xl border border-amber-900/30 overflow-hidden bg-slate-900/60">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-amber-100/90">
                    <thead className="bg-slate-950/80 text-[11px] font-bold uppercase tracking-wider text-amber-400 border-b border-amber-900/40">
                      <tr>
                        <th className="p-3">Timestamp</th>
                        <th className="p-3">Action</th>
                        <th className="p-3">Actor</th>
                        <th className="p-3">Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 font-mono text-[11px]">
                      {auditLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-900/40">
                          <td className="p-3 text-amber-200/60 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                          <td className="p-3 font-bold text-amber-300">{log.action}</td>
                          <td className="p-3 text-amber-400">{log.performedBy}</td>
                          <td className="p-3 font-sans text-xs text-amber-100/90">{log.details}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal for Add / Edit Prize */}
        {isAddPrizeOpen && editingPrize && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <div className="relative w-full max-w-lg rounded-2xl bg-[#0c0d18] border border-amber-500/50 p-6 shadow-2xl">
              <button
                onClick={() => {
                  setIsAddPrizeOpen(false);
                  setEditingPrize(null);
                }}
                className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>

              <h3 className="text-lg font-bold text-amber-200 mb-4" style={{ fontFamily: "'Cinzel', serif" }}>
                {editingPrize.id ? 'Edit Prize Item' : 'Add New Prize Item'}
              </h3>

              <form onSubmit={handleSavePrize} className="space-y-3 text-xs">
                <div>
                  <label className="block text-amber-300 mb-1 font-semibold">Prize Name (English) *</label>
                  <input
                    type="text"
                    required
                    value={editingPrize.name || ''}
                    onChange={(e) => setEditingPrize({ ...editingPrize, name: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                  />
                </div>

                <div>
                  <label className="block text-amber-300 mb-1 font-semibold">Prize Name (Hindi)</label>
                  <input
                    type="text"
                    value={editingPrize.nameHi || ''}
                    onChange={(e) => setEditingPrize({ ...editingPrize, nameHi: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-amber-300 mb-1 font-semibold">Diya Category *</label>
                    <select
                      value={editingPrize.contestId || 'diya-1'}
                      onChange={(e) => setEditingPrize({ ...editingPrize, contestId: e.target.value })}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                    >
                      <option value="diya-1">Diya 1 (₹199)</option>
                      <option value="diya-2">Diya 2 (₹499)</option>
                      <option value="diya-3">Diya 3 (₹999)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-amber-300 mb-1 font-semibold">Market Value</label>
                    <input
                      type="text"
                      value={editingPrize.marketValue || ''}
                      onChange={(e) => setEditingPrize({ ...editingPrize, marketValue: e.target.value })}
                      placeholder="e.g. ₹50,000"
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-amber-300 mb-1 font-semibold">Image URL</label>
                  <input
                    type="text"
                    value={editingPrize.imageUrl || ''}
                    onChange={(e) => setEditingPrize({ ...editingPrize, imageUrl: e.target.value })}
                    placeholder="https://..."
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                  />
                </div>

                <div>
                  <label className="block text-amber-300 mb-1 font-semibold">Description</label>
                  <textarea
                    rows={2}
                    value={editingPrize.description || ''}
                    onChange={(e) => setEditingPrize({ ...editingPrize, description: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddPrizeOpen(false);
                      setEditingPrize(null);
                    }}
                    className="px-3 py-1.5 rounded-lg text-slate-300 hover:bg-white/10"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg font-bold text-slate-950 bg-amber-400 hover:bg-amber-300"
                  >
                    Save Prize
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal for Resetting User Password */}
        {resetPassUser && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <div className="relative w-full max-w-sm rounded-2xl bg-[#0c0d18] border border-amber-500/50 p-6 shadow-2xl">
              <button
                onClick={() => setResetPassUser(null)}
                className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
              <h3 className="text-base font-bold text-amber-200 mb-2">
                Reset Password for @{resetPassUser.username}
              </h3>
              <form onSubmit={handleAdminResetPassword} className="space-y-3 text-xs">
                <div>
                  <label className="block text-amber-300 mb-1 font-semibold">New Password (Min 6 chars)</label>
                  <input
                    type="password"
                    required
                    value={newPasswordInput}
                    onChange={(e) => setNewPasswordInput(e.target.value)}
                    placeholder="Enter new password"
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-amber-800/40 text-amber-100"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setResetPassUser(null)}
                    className="px-3 py-1.5 rounded-lg text-slate-300 hover:bg-white/10"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg font-bold text-slate-950 bg-amber-400 hover:bg-amber-300"
                  >
                    Update Password
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal for Receipt Screenshot Preview */}
        {selectedReceipt && (
          <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/90">
            <div className="relative max-w-lg max-h-[85vh] overflow-hidden rounded-xl border border-amber-500/50">
              <button
                onClick={() => setSelectedReceipt(null)}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-slate-950/80 text-white"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={selectedReceipt}
                alt="Receipt Proof"
                className="w-full h-auto max-h-[85vh] object-contain"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
