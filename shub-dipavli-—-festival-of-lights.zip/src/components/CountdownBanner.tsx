import React, { useState, useEffect } from 'react';
import { Language, translations } from '../lib/translations';
import { Calendar, Award, ShieldCheck, Sparkles } from 'lucide-react';

interface CountdownBannerProps {
  lang: Language;
  targetDateIso: string;
  displayDateText: string;
  isResultPublished: boolean;
  onOpenResults: () => void;
}

export const CountdownBanner: React.FC<CountdownBannerProps> = ({
  lang,
  targetDateIso,
  displayDateText,
  isResultPublished,
  onOpenResults
}) => {
  const t = translations[lang];

  const calculateTimeLeft = () => {
    const difference = new Date(targetDateIso).getTime() - Date.now();
    if (difference <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true };
    }

    return {
      days: Math.floor(difference / (1000 * 60 * 60 * 24)),
      hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((difference / 1000 / 60) % 60),
      seconds: Math.floor((difference / 1000) % 60),
      isPast: false
    };
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
  }, [targetDateIso]);

  return (
    <section id="results" className="relative py-8 px-4 sm:px-6 max-w-5xl mx-auto my-6">
      {/* Decorative Golden Ambient Border Box */}
      <div className="relative rounded-2xl bg-gradient-to-b from-amber-950/70 via-slate-900/90 to-amber-950/70 border border-amber-500/40 p-6 sm:p-8 shadow-[0_0_50px_-10px_rgba(245,158,11,0.25)] text-center overflow-hidden">
        {/* Subtle festive background illumination */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-amber-500/15 blur-2xl pointer-events-none" />

        {/* Small auspicious kicker */}
        <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-widest uppercase text-amber-400 mb-2">
          <Calendar className="w-3.5 h-3.5" />
          <span>OFFICIAL FESTIVAL LUCKY DRAW SCHEDULE</span>
        </div>

        {/* Prominent Required Text */}
        <h2
          className="text-xs sm:text-sm font-bold tracking-[0.25em] text-amber-300 uppercase mb-1"
          style={{ fontFamily: "'Outfit', sans-serif" }}
        >
          {t.resultAnnounceHeader}
        </h2>
        <div
          className="text-3xl sm:text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500 py-1"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          {displayDateText || '7 NOVEMBER 2026'}
        </div>

        {/* Countdown Digits or Official Results Published Banner */}
        {isResultPublished || timeLeft.isPast ? (
          <div className="mt-6 flex flex-col items-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-950/80 border border-emerald-500/60 rounded-xl text-emerald-300 text-sm font-semibold mb-4">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>{isResultPublished ? 'Official Results Published & Audited!' : 'Result Draw Time Arrived! View Results.'}</span>
            </div>
            <button
              onClick={onOpenResults}
              className="flex items-center gap-2 px-6 py-3 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 rounded-xl shadow-lg shadow-amber-500/25 transform hover:scale-[1.02] active:scale-[0.98] transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>View Official Winners List</span>
            </button>
          </div>
        ) : (
          <div className="mt-6">
            <div className="grid grid-cols-4 gap-2 sm:gap-4 max-w-lg mx-auto">
              {/* Days */}
              <div className="bg-slate-950/80 border border-amber-600/30 rounded-xl p-3 sm:p-4 shadow-inner">
                <span className="block text-2xl sm:text-4xl font-extrabold text-amber-300 tabular-nums font-mono">
                  {String(timeLeft.days).padStart(2, '0')}
                </span>
                <span className="text-[10px] sm:text-xs font-semibold tracking-wider text-amber-200/70 uppercase">
                  {t.countdownDays}
                </span>
              </div>
              {/* Hours */}
              <div className="bg-slate-950/80 border border-amber-600/30 rounded-xl p-3 sm:p-4 shadow-inner">
                <span className="block text-2xl sm:text-4xl font-extrabold text-amber-300 tabular-nums font-mono">
                  {String(timeLeft.hours).padStart(2, '0')}
                </span>
                <span className="text-[10px] sm:text-xs font-semibold tracking-wider text-amber-200/70 uppercase">
                  {t.countdownHours}
                </span>
              </div>
              {/* Minutes */}
              <div className="bg-slate-950/80 border border-amber-600/30 rounded-xl p-3 sm:p-4 shadow-inner">
                <span className="block text-2xl sm:text-4xl font-extrabold text-amber-300 tabular-nums font-mono">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </span>
                <span className="text-[10px] sm:text-xs font-semibold tracking-wider text-amber-200/70 uppercase">
                  {t.countdownMins}
                </span>
              </div>
              {/* Seconds */}
              <div className="bg-slate-950/80 border border-amber-600/30 rounded-xl p-3 sm:p-4 shadow-inner">
                <span className="block text-2xl sm:text-4xl font-extrabold text-amber-400 tabular-nums font-mono animate-pulse">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </span>
                <span className="text-[10px] sm:text-xs font-semibold tracking-wider text-amber-200/70 uppercase">
                  {t.countdownSecs}
                </span>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-center gap-4 text-xs text-amber-200/70">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>{t.fairSelection}</span>
              </span>
              <span>·</span>
              <button
                onClick={onOpenResults}
                className="text-amber-400 hover:text-amber-300 underline underline-offset-4 font-medium transition-colors"
              >
                Verification & Procedure
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
