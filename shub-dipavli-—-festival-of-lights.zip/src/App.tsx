import React, { useState, useEffect } from 'react';
import {
  User,
  DiyaContest,
  PrizeItem,
  PaymentConfig,
  SiteSettings,
  WinnerRecord,
  ContestEntry
} from './types';
import { Language } from './lib/translations';
import { api, tokenStorage } from './lib/api';

import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CountdownBanner } from './components/CountdownBanner';
import { DiyaCategories } from './components/DiyaCategories';
import { DiyaSelectionModal } from './components/DiyaSelectionModal';
import { PrizeCatalogModal } from './components/PrizeCatalogModal';
import { ParticipationModal } from './components/ParticipationModal';
import { ClientAuthModal } from './components/ClientAuthModal';
import { UserDashboard } from './components/UserDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { ResultsModal } from './components/ResultsModal';
import { OfficialRulesModal } from './components/OfficialRulesModal';
import { Footer } from './components/Footer';
import { FloatingSparkles } from './components/DiwaliDecorations';

import { Sparkles, Gift, ArrowRight, ShieldCheck, Flame } from 'lucide-react';
import {
  initialContests,
  initialPrizes,
  initialPaymentConfig,
  initialSiteSettings
} from './data/seedData';
import { initializeClientStore } from './lib/clientStore';

export default function App() {
  const [lang, setLang] = useState<Language>('en');

  // Application Data States initialized with rich datasets immediately
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [contests, setContests] = useState<DiyaContest[]>(initialContests);
  const [prizes, setPrizes] = useState<PrizeItem[]>(initialPrizes);
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig | null>(initialPaymentConfig);
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(initialSiteSettings);
  const [resultsData, setResultsData] = useState<{
    isResultPublished: boolean;
    announcementDate: string;
    displayDate: string;
    winners: WinnerRecord[];
  }>({
    isResultPublished: false,
    announcementDate: initialSiteSettings.resultAnnouncementDate,
    displayDate: initialSiteSettings.resultDisplayDate,
    winners: []
  });

  const [isLoading, setIsLoading] = useState(false);

  // Modals
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState(false);
  const [isDiyaPopupOpen, setIsDiyaPopupOpen] = useState(false);
  const [isPrizeCatalogOpen, setIsPrizeCatalogOpen] = useState(false);
  const [isParticipationOpen, setIsParticipationOpen] = useState(false);
  const [isResultsOpen, setIsResultsOpen] = useState(false);
  const [isRulesOpen, setIsRulesOpen] = useState(false);

  // Selected Contest Context
  const [selectedContest, setSelectedContest] = useState<DiyaContest | null>(null);

  // Initialize and load data from backend or resilient local store
  const refreshAllData = async () => {
    try {
      await initializeClientStore();

      // Fetch each resource safely
      const [contestsRes, prizesRes, paymentRes, settingsRes, resultsRes] = await Promise.allSettled([
        api.getContests(),
        api.getPrizes(),
        api.getPaymentConfig(),
        api.getSettings(),
        api.getResults()
      ]);

      if (contestsRes.status === 'fulfilled' && contestsRes.value?.contests?.length) {
        setContests(contestsRes.value.contests);
      }
      if (prizesRes.status === 'fulfilled' && prizesRes.value?.prizes?.length) {
        setPrizes(prizesRes.value.prizes);
      }
      if (paymentRes.status === 'fulfilled' && paymentRes.value?.paymentConfig) {
        setPaymentConfig(paymentRes.value.paymentConfig);
      }
      if (settingsRes.status === 'fulfilled' && settingsRes.value?.settings) {
        setSiteSettings(settingsRes.value.settings);
      }
      if (resultsRes.status === 'fulfilled' && resultsRes.value) {
        setResultsData(resultsRes.value);
      }

      // Check existing session token
      const token = tokenStorage.get();
      if (token) {
        try {
          const meRes = await api.getMe();
          if (meRes?.user) {
            setCurrentUser(meRes.user);
          }
        } catch {
          tokenStorage.clear();
          setCurrentUser(null);
        }
      }
    } catch (err) {
      console.error('Error syncing festival data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshAllData();

    // Check for #admin hash to open login directly
    if (window.location.hash === '#admin') {
      setIsAuthOpen(true);
    }

    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        setIsAuthOpen(true);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // When a Diya category is clicked -> Display the exact required Diya Selection Popup
  const handleSelectDiyaCategory = (contest: DiyaContest) => {
    setSelectedContest(contest);
    setIsDiyaPopupOpen(true);
  };

  // When "View Prizes" is clicked from category or popup
  const handleViewPrizes = (contest?: DiyaContest) => {
    if (contest) setSelectedContest(contest);
    setIsPrizeCatalogOpen(true);
  };

  // When "Continue" is clicked from popup -> Open Paid Participation flow
  const handleContinueParticipation = () => {
    if (!currentUser) {
      setIsAuthOpen(true);
    } else {
      setIsParticipationOpen(true);
    }
  };

  // Auth Success Handler
  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setIsAdminDashboardOpen(true);
    } else {
      setIsDashboardOpen(true);
    }
  };

  // Successful participation entry
  const handleParticipationSuccess = (_entry: ContestEntry) => {
    refreshAllData();
  };

  return (
    <div className="min-h-screen bg-[#0b0c16] text-amber-50 selection:bg-amber-500 selection:text-slate-950 relative overflow-x-hidden font-sans">
      {/* Background Ambient Floating Sparkles & Diya lights */}
      <FloatingSparkles />

      {/* Top Bar Header adhering strictly to Top Bar Contract */}
      <Header
        lang={lang}
        onToggleLang={() => setLang(lang === 'en' ? 'hi' : 'en')}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenDashboard={() => setIsDashboardOpen(true)}
        onOpenAdmin={() => {
          if (currentUser?.role === 'admin') {
            setIsAdminDashboardOpen(true);
          } else {
            setIsAuthOpen(true);
          }
        }}
      />

      <main className="relative z-10">
        {/* Festive Hero Banner */}
        {siteSettings && (
          <Hero
            lang={lang}
            settings={siteSettings}
            onExploreClick={() => {
              const el = document.getElementById('categories');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            onViewCatalogClick={() => {
              setSelectedContest(null);
              setIsPrizeCatalogOpen(true);
            }}
          />
        )}

        {/* Result Announcement & Live Countdown Banner */}
        <CountdownBanner
          lang={lang}
          targetDateIso={siteSettings?.resultAnnouncementDate || resultsData.announcementDate}
          displayDateText={siteSettings?.resultDisplayDate || resultsData.displayDate}
          isResultPublished={siteSettings?.isResultPublished || resultsData.isResultPublished}
          onOpenResults={() => setIsResultsOpen(true)}
        />

        {/* 3 Diya Categories Cards (Diya 1: ₹199, Diya 2: ₹499, Diya 3: ₹999) */}
        <DiyaCategories
          lang={lang}
          contests={contests}
          prizes={prizes}
          onSelectDiya={handleSelectDiyaCategory}
          onViewPrizes={(contest) => {
            setSelectedContest(contest);
            setIsPrizeCatalogOpen(true);
          }}
        />

        {/* Featured 49 Prize Catalog Showcase Section on Homepage */}
        <section id="prizes" className="py-14 px-4 sm:px-6 max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-widest mb-1.5">
                <Gift className="w-3.5 h-3.5" />
                <span>Verified Grand Gift Catalog</span>
              </div>
              <h2
                className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500 uppercase"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Mega Festival Prize Showcase
              </h2>
              <p className="text-xs sm:text-sm text-amber-200/70 mt-1">
                Explore all 49 genuine festive gifts available across Diya 1, Diya 2, and Diya 3 categories.
              </p>
            </div>

            <button
              onClick={() => {
                setSelectedContest(null);
                setIsPrizeCatalogOpen(true);
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-md transition-all self-start sm:self-auto cursor-pointer"
            >
              <span>Explore All 49 Prizes</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Highlights Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            {prizes.slice(0, 12).map((prize) => {
              const contest = contests.find(c => c.id === prize.contestId);
              return (
                <div
                  key={prize.id}
                  onClick={() => {
                    if (contest) handleSelectDiyaCategory(contest);
                  }}
                  className="group rounded-xl bg-slate-900/60 border border-amber-900/30 hover:border-amber-500/60 transition-all p-2.5 flex flex-col justify-between cursor-pointer"
                >
                  <div className="aspect-[4/3] rounded-lg overflow-hidden bg-slate-950 relative mb-2">
                    <img
                      src={prize.imageUrl}
                      alt={prize.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-1 right-1 px-1.5 py-0.5 rounded bg-amber-500/90 text-slate-950 text-[9px] font-black font-mono">
                      {prize.marketValue}
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-400 uppercase font-bold tracking-wider block">
                      {contest?.title.split('—')[0].trim()}
                    </span>
                    <h4 className="text-xs font-bold text-amber-100 group-hover:text-amber-300 line-clamp-1">
                      {lang === 'hi' ? prize.nameHi || prize.name : prize.name}
                    </h4>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Auspicious Trust & Fair Play Assurance Banner */}
        <section id="rules" className="py-8 px-4 sm:px-6 max-w-5xl mx-auto">
          <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-950 to-amber-950/40 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Fair Selection & Legal Transparency</span>
              </div>
              <h3
                className="text-lg sm:text-xl font-bold text-amber-100"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                100% Genuine Festive Celebration
              </h3>
              <p className="text-xs text-amber-200/70 max-w-xl leading-relaxed">
                Participant entry contributions are securely logged. All winning tickets are chosen through an audited cryptographic random draw on {siteSettings?.resultDisplayDate || '7 NOVEMBER 2026'}. Open to Indian citizens aged 18+.
              </p>
            </div>

            <button
              onClick={() => setIsRulesOpen(true)}
              className="px-5 py-2.5 rounded-xl text-xs font-bold text-amber-200 bg-amber-950/60 hover:bg-amber-900/60 border border-amber-600/50 hover:border-amber-500 transition-colors shrink-0 cursor-pointer"
            >
              Read Official Rules
            </button>
          </div>
        </section>
      </main>

      {/* Regal Footer */}
      {siteSettings && (
        <Footer
          settings={siteSettings}
          lang={lang}
          onOpenRules={() => setIsRulesOpen(true)}
          onOpenResults={() => setIsResultsOpen(true)}
          onOpenAdmin={() => {
            if (currentUser?.role === 'admin') {
              setIsAdminDashboardOpen(true);
            } else {
              setIsAuthOpen(true);
            }
          }}
        />
      )}

      {/* --- MODALS & WORKFLOWS --- */}

      {/* 1. Diya Selection Modal (Exact Requirement: "Heyy Dear! ✨ Celebrate Diwali with SHUB DIPAVLI!...") */}
      <DiyaSelectionModal
        isOpen={isDiyaPopupOpen}
        onClose={() => setIsDiyaPopupOpen(false)}
        contest={selectedContest}
        lang={lang}
        onContinue={handleContinueParticipation}
        onViewPrizes={() => handleViewPrizes(selectedContest || undefined)}
        onViewRules={() => setIsRulesOpen(true)}
      />

      {/* 2. Prize Catalog Modal (All 49 Prizes) */}
      <PrizeCatalogModal
        isOpen={isPrizeCatalogOpen}
        onClose={() => setIsPrizeCatalogOpen(false)}
        prizes={prizes}
        contests={contests}
        selectedContestId={selectedContest?.id}
        lang={lang}
        onParticipateInContest={(contest) => {
          setSelectedContest(contest);
          handleSelectDiyaCategory(contest);
        }}
      />

      {/* 3. Paid Contest Participation & Payment Checkout */}
      {paymentConfig && (
        <ParticipationModal
          isOpen={isParticipationOpen}
          onClose={() => setIsParticipationOpen(false)}
          contest={selectedContest}
          paymentConfig={paymentConfig}
          currentUser={currentUser}
          lang={lang}
          onOpenAuth={() => {
            setIsParticipationOpen(false);
            setIsAuthOpen(true);
          }}
          onSuccess={handleParticipationSuccess}
        />
      )}

      {/* 4. Client Authentication Modal */}
      <ClientAuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        lang={lang}
        onAuthSuccess={handleAuthSuccess}
      />


      {/* 6. User Personal Dashboard */}
      {currentUser && (
        <UserDashboard
          isOpen={isDashboardOpen}
          onClose={() => setIsDashboardOpen(false)}
          user={currentUser}
          lang={lang}
          contests={contests}
          resultDisplayDate={siteSettings?.resultDisplayDate || '7 NOVEMBER 2026'}
          onLogout={() => {
            setCurrentUser(null);
          }}
          onSelectDiya={(contest) => {
            setIsDashboardOpen(false);
            handleSelectDiyaCategory(contest);
          }}
          onOpenContact={() => {
            setIsDashboardOpen(false);
            const el = document.getElementById('contact');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />
      )}

      {/* 7. Comprehensive Admin Dashboard */}
      {currentUser?.role === 'admin' && (
        <AdminDashboard
          isOpen={isAdminDashboardOpen}
          onClose={() => setIsAdminDashboardOpen(false)}
          adminUser={currentUser}
          onLogout={() => {
            setCurrentUser(null);
          }}
          onDataUpdated={refreshAllData}
        />
      )}

      {/* 8. Results & Transparency Certificate Modal */}
      <ResultsModal
        isOpen={isResultsOpen}
        onClose={() => setIsResultsOpen(false)}
        isResultPublished={siteSettings?.isResultPublished || resultsData.isResultPublished}
        announcementDate={siteSettings?.resultAnnouncementDate || resultsData.announcementDate}
        displayDateText={siteSettings?.resultDisplayDate || resultsData.displayDate}
        winners={resultsData.winners}
        lang={lang}
      />

      {/* 9. Official Rules Modal */}
      {siteSettings && (
        <OfficialRulesModal
          isOpen={isRulesOpen}
          onClose={() => setIsRulesOpen(false)}
          settings={siteSettings}
          lang={lang}
        />
      )}
    </div>
  );
}
