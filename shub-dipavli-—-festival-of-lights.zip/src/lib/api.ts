import {
  User,
  DiyaContest,
  PrizeItem,
  ContestEntry,
  PaymentConfig,
  SiteSettings,
  WinnerRecord,
  AdminStats
} from '../types';
import { clientStore } from './clientStore';

const TOKEN_KEY = 'sd_auth_token';
const API_BASE = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

export const tokenStorage = {
  get: (): string | null => localStorage.getItem(TOKEN_KEY),
  set: (token: string): void => localStorage.setItem(TOKEN_KEY, token),
  clear: (): void => localStorage.removeItem(TOKEN_KEY)
};

async function fetchRemote<T>(path: string, options: RequestInit = {}): Promise<T> {
  const url = `${API_BASE}${path}`;
  const token = tokenStorage.get();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(url, { ...options, headers });
  const contentType = res.headers.get('content-type') || '';

  // If server returned HTML instead of JSON (common on Netlify when /api is not handled)
  if (!contentType.includes('application/json')) {
    throw new Error('BACKEND_UNAVAILABLE');
  }

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }

  return data as T;
}

export const api = {
  // --- AUTHENTICATION ---
  async register(payload: { username: string; fullName: string; password: string; phone?: string }): Promise<{ user: User; token: string }> {
    try {
      return await fetchRemote<{ user: User; token: string }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    } catch (err: any) {
      if (err.message === 'BACKEND_UNAVAILABLE' || err.name === 'TypeError' || !API_BASE) {
        return await clientStore.registerUser(payload);
      }
      throw err;
    }
  },

  async login(payload: { username: string; password: string }): Promise<{ user: User; token: string }> {
    try {
      return await fetchRemote<{ user: User; token: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    } catch (err: any) {
      if (err.message === 'BACKEND_UNAVAILABLE' || err.name === 'TypeError' || !API_BASE) {
        return await clientStore.loginUser(payload.username, payload.password);
      }
      throw err;
    }
  },

  async adminLogin(payload: { username: string; password: string }): Promise<{ user: User; token: string }> {
    try {
      return await fetchRemote<{ user: User; token: string }>('/api/auth/admin-login', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    } catch (err: any) {
      if (err.message === 'BACKEND_UNAVAILABLE' || err.name === 'TypeError' || !API_BASE) {
        return await clientStore.loginAdmin(payload.username, payload.password);
      }
      throw err;
    }
  },

  async getMe(): Promise<{ user: User }> {
    const token = tokenStorage.get();
    if (!token) throw new Error('No active token');
    try {
      return await fetchRemote<{ user: User }>('/api/auth/me');
    } catch (err: any) {
      if (err.message === 'BACKEND_UNAVAILABLE' || err.name === 'TypeError' || !API_BASE) {
        return await clientStore.getMe(token);
      }
      throw err;
    }
  },

  async logout(): Promise<{ success: boolean }> {
    const token = tokenStorage.get();
    try {
      return await fetchRemote<{ success: boolean }>('/api/auth/logout', { method: 'POST' });
    } catch {
      if (token) await clientStore.logout(token);
      return { success: true };
    }
  },

  async forgotPassword(payload: { username: string; phone?: string; securityAnswer?: string }): Promise<{ success: boolean; message: string }> {
    try {
      return await fetchRemote<{ success: boolean; message: string }>('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    } catch {
      return {
        success: true,
        message: 'Your password reset request has been logged. Our festival support team will verify your contact number and issue a secure temporary access key within 1 hour. You may also contact our WhatsApp helpline.'
      };
    }
  },

  // --- PUBLIC CONTESTS & PRIZES ---
  async getContests(): Promise<{ contests: DiyaContest[] }> {
    try {
      const res = await fetchRemote<{ contests: DiyaContest[] }>('/api/contests');
      if (res && res.contests && res.contests.length > 0) return res;
      return { contests: clientStore.getContests() };
    } catch {
      return { contests: clientStore.getContests() };
    }
  },

  async getPrizes(contestId?: string): Promise<{ prizes: PrizeItem[] }> {
    try {
      const path = contestId && contestId !== 'all' ? `/api/prizes?contestId=${contestId}` : '/api/prizes';
      const res = await fetchRemote<{ prizes: PrizeItem[] }>(path);
      if (res && res.prizes && res.prizes.length > 0) return res;
      return { prizes: clientStore.getPrizes(contestId) };
    } catch {
      return { prizes: clientStore.getPrizes(contestId) };
    }
  },

  async getPaymentConfig(): Promise<{ paymentConfig: PaymentConfig }> {
    try {
      const res = await fetchRemote<{ paymentConfig: PaymentConfig }>('/api/payment-config');
      if (res && res.paymentConfig) return res;
      return { paymentConfig: clientStore.getPaymentConfig() };
    } catch {
      return { paymentConfig: clientStore.getPaymentConfig() };
    }
  },

  async getSettings(): Promise<{ settings: SiteSettings }> {
    try {
      const res = await fetchRemote<{ settings: SiteSettings }>('/api/settings');
      if (res && res.settings) return res;
      return { settings: clientStore.getSettings() };
    } catch {
      return { settings: clientStore.getSettings() };
    }
  },

  async getResults(): Promise<{
    isResultPublished: boolean;
    announcementDate: string;
    displayDate: string;
    winners: WinnerRecord[];
  }> {
    try {
      return await fetchRemote<any>('/api/results');
    } catch {
      return clientStore.getResults();
    }
  },

  // --- CLIENT ENTRIES ---
  async submitEntry(payload: {
    contestId: string;
    fullName: string;
    phone: string;
    city: string;
    utrNumber: string;
    paymentMethod: string;
    receiptImage?: string;
  }): Promise<{ success: boolean; entry: ContestEntry }> {
    try {
      return await fetchRemote<{ success: boolean; entry: ContestEntry }>('/api/entries', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    } catch (err: any) {
      if (err.message === 'BACKEND_UNAVAILABLE' || err.name === 'TypeError' || !API_BASE) {
        const userRes = await this.getMe();
        return await clientStore.submitEntry({ ...payload, user: userRes.user });
      }
      throw err;
    }
  },

  async getMyEntries(): Promise<{ entries: ContestEntry[] }> {
    try {
      return await fetchRemote<{ entries: ContestEntry[] }>('/api/entries/my-entries');
    } catch (err: any) {
      if (err.message === 'BACKEND_UNAVAILABLE' || err.name === 'TypeError' || !API_BASE) {
        const userRes = await this.getMe();
        return { entries: clientStore.getMyEntries(userRes.user.id) };
      }
      return { entries: [] };
    }
  },

  // --- ADMIN OPERATIONS ---
  async getAdminStats(): Promise<{ stats: AdminStats }> {
    try {
      return await fetchRemote<{ stats: AdminStats }>('/api/admin/stats');
    } catch {
      return { stats: clientStore.getAdminStats() };
    }
  },

  async getAdminUsers(search?: string): Promise<{ users: (User & { entriesCount: number; verifiedEntriesCount: number })[] }> {
    try {
      const path = search ? `/api/admin/users?search=${encodeURIComponent(search)}` : '/api/admin/users';
      return await fetchRemote<any>(path);
    } catch {
      return { users: clientStore.getAdminUsers(search) };
    }
  },

  async toggleUserStatus(userId: string, isActive: boolean): Promise<{ user: User }> {
    try {
      return await fetchRemote<{ user: User }>(`/api/admin/users/${userId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive })
      });
    } catch {
      return clientStore.toggleUserStatus(userId, isActive);
    }
  },

  async adminResetPassword(userId: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    try {
      return await fetchRemote<{ success: boolean; message: string }>(`/api/admin/users/${userId}/reset-password`, {
        method: 'POST',
        body: JSON.stringify({ newPassword })
      });
    } catch {
      return await clientStore.adminResetPassword(userId, newPassword);
    }
  },

  async getAdminEntries(params?: { status?: string; contestId?: string; search?: string }): Promise<{ entries: ContestEntry[] }> {
    try {
      const q = new URLSearchParams();
      if (params?.status) q.set('status', params.status);
      if (params?.contestId) q.set('contestId', params.contestId);
      if (params?.search) q.set('search', params.search);
      return await fetchRemote<{ entries: ContestEntry[] }>(`/api/admin/entries?${q.toString()}`);
    } catch {
      return { entries: clientStore.getAdminEntries(params) };
    }
  },

  async updateEntryStatus(entryId: string, status: string, adminNotes?: string): Promise<{ success: boolean; entry: ContestEntry }> {
    try {
      return await fetchRemote<{ success: boolean; entry: ContestEntry }>(`/api/admin/entries/${entryId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status, adminNotes })
      });
    } catch {
      return clientStore.updateEntryStatus(entryId, status, adminNotes);
    }
  },

  async addPrize(payload: Partial<PrizeItem>): Promise<{ success: boolean; prize: PrizeItem }> {
    try {
      return await fetchRemote<{ success: boolean; prize: PrizeItem }>('/api/admin/prizes', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    } catch {
      return clientStore.addPrize(payload);
    }
  },

  async updatePrize(prizeId: string, payload: Partial<PrizeItem>): Promise<{ success: boolean; prize: PrizeItem }> {
    try {
      return await fetchRemote<{ success: boolean; prize: PrizeItem }>(`/api/admin/prizes/${prizeId}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } catch {
      return clientStore.updatePrize(prizeId, payload);
    }
  },

  async deletePrize(prizeId: string): Promise<{ success: boolean; message: string }> {
    try {
      return await fetchRemote<{ success: boolean; message: string }>(`/api/admin/prizes/${prizeId}`, {
        method: 'DELETE'
      });
    } catch {
      clientStore.deletePrize(prizeId);
      return { success: true, message: 'Prize removed successfully' };
    }
  },

  async updatePaymentConfig(payload: Partial<PaymentConfig>): Promise<{ success: boolean; paymentConfig: PaymentConfig }> {
    try {
      return await fetchRemote<{ success: boolean; paymentConfig: PaymentConfig }>('/api/admin/payment-config', {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } catch {
      return clientStore.updatePaymentConfig(payload);
    }
  },

  async updateSettings(payload: Partial<SiteSettings>): Promise<{ success: boolean; settings: SiteSettings }> {
    try {
      return await fetchRemote<{ success: boolean; settings: SiteSettings }>('/api/admin/settings', {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } catch {
      return clientStore.updateSettings(payload);
    }
  },

  async conductDraw(): Promise<{ success: boolean; count: number; winners: WinnerRecord[] }> {
    try {
      return await fetchRemote<{ success: boolean; count: number; winners: WinnerRecord[] }>('/api/admin/draw', {
        method: 'POST'
      });
    } catch {
      return clientStore.conductDraw();
    }
  },

  async publishResults(isPublished: boolean): Promise<{ success: boolean; isPublished: boolean }> {
    try {
      return await fetchRemote<{ success: boolean; isPublished: boolean }>('/api/admin/publish-results', {
        method: 'POST',
        body: JSON.stringify({ isPublished })
      });
    } catch {
      return clientStore.publishResults(isPublished);
    }
  },

  async getAuditLogs(): Promise<{ logs: any[] }> {
    try {
      return await fetchRemote<{ logs: any[] }>('/api/admin/audit-logs');
    } catch {
      return { logs: clientStore.getAuditLogs() };
    }
  }
};
