import {
  User,
  DiyaContest,
  PrizeItem,
  ContestEntry,
  PaymentConfig,
  SiteSettings,
  WinnerRecord,
  AdminStats
} from '../types';
import {
  initialContests,
  initialPrizes,
  initialPaymentConfig,
  initialSiteSettings
} from '../data/seedData';

export interface StoredUser extends User {
  passwordHash: string;
  salt: string;
}

export interface StoredSession {
  token: string;
  userId: string;
  role: 'client' | 'admin';
  expiresAt: number;
}

// Helper for Web Crypto PBKDF2/SHA-256 hashing
async function hashPasswordAsync(password: string, saltHex?: string): Promise<{ hash: string; salt: string }> {
  const enc = new TextEncoder();
  const salt = saltHex
    ? hexToBytes(saltHex)
    : window.crypto.getRandomValues(new Uint8Array(16));

  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const derivedBits = await window.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: (salt.buffer as ArrayBuffer).slice(salt.byteOffset, salt.byteOffset + salt.byteLength),
      iterations: 10000,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );

  return {
    hash: bytesToHex(new Uint8Array(derivedBits)),
    salt: bytesToHex(salt)
  };
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

function generateRandomToken(): string {
  const bytes = window.crypto.getRandomValues(new Uint8Array(24));
  return bytesToHex(bytes);
}

function generateTicketNumber(contestId: string): string {
  const prefix = contestId === 'diya-1' ? 'D1' : contestId === 'diya-2' ? 'D2' : 'D3';
  const randomPart = Math.floor(100000 + Math.random() * 900000);
  return `SD-${prefix}-${randomPart}`;
}

const STORAGE_KEYS = {
  USERS: 'sd_client_users',
  SESSIONS: 'sd_client_sessions',
  CONTESTS: 'sd_client_contests',
  PRIZES: 'sd_client_prizes',
  ENTRIES: 'sd_client_entries',
  PAYMENT: 'sd_client_payment_config',
  SETTINGS: 'sd_client_settings',
  WINNERS: 'sd_client_winners',
  AUDIT: 'sd_client_audit_logs'
};

// Ensure initial database exists in localStorage
export async function initializeClientStore(): Promise<void> {
  if (!localStorage.getItem(STORAGE_KEYS.CONTESTS)) {
    localStorage.setItem(STORAGE_KEYS.CONTESTS, JSON.stringify(initialContests));
  }
  if (!localStorage.getItem(STORAGE_KEYS.PRIZES)) {
    localStorage.setItem(STORAGE_KEYS.PRIZES, JSON.stringify(initialPrizes));
  }
  if (!localStorage.getItem(STORAGE_KEYS.PAYMENT)) {
    localStorage.setItem(STORAGE_KEYS.PAYMENT, JSON.stringify(initialPaymentConfig));
  }
  if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(initialSiteSettings));
  }
  if (!localStorage.getItem(STORAGE_KEYS.ENTRIES)) {
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify([]));
  }
  if (!localStorage.getItem(STORAGE_KEYS.WINNERS)) {
    localStorage.setItem(STORAGE_KEYS.WINNERS, JSON.stringify([]));
  }
  if (!localStorage.getItem(STORAGE_KEYS.AUDIT)) {
    localStorage.setItem(
      STORAGE_KEYS.AUDIT,
      JSON.stringify([
        {
          id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
          action: 'CLIENT_STORE_INITIALIZED',
          performedBy: 'System',
          details: 'Initial festival store seeded with 3 Diya categories and 49 verified prizes.',
          timestamp: new Date().toISOString()
        }
      ])
    );
  }

  // Ensure Admin01 exists with hashed password Admin@01
  const usersJson = localStorage.getItem(STORAGE_KEYS.USERS);
  let users: StoredUser[] = usersJson ? JSON.parse(usersJson) : [];
  const adminIndex = users.findIndex(u => u.username.toLowerCase() === 'admin01');

  const adminHash = await hashPasswordAsync('Admin@01');
  if (adminIndex === -1) {
    const defaultAdmin: StoredUser = {
      id: 'admin-01',
      username: 'Admin01',
      fullName: 'Diwali Executive Administrator',
      phone: '+919876543210',
      role: 'admin',
      isActive: true,
      createdAt: new Date().toISOString(),
      passwordHash: adminHash.hash,
      salt: adminHash.salt
    };
    users.push(defaultAdmin);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  } else {
    // Synchronize existing Admin01 record with updated hash for Admin@01
    users[adminIndex].passwordHash = adminHash.hash;
    users[adminIndex].salt = adminHash.salt;
    users[adminIndex].role = 'admin';
    users[adminIndex].isActive = true;
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }
}

export const clientStore = {
  // Authentication
  async registerUser(payload: { username: string; fullName: string; password: string; phone?: string }) {
    await initializeClientStore();
    const cleanUsername = payload.username.trim();
    if (cleanUsername.toLowerCase() === 'admin01' || cleanUsername.toLowerCase() === 'admin') {
      throw new Error('This username is reserved. Please choose another.');
    }

    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const existing = users.find(u => u.username.toLowerCase() === cleanUsername.toLowerCase());
    if (existing) {
      throw new Error('This username is already taken. Please choose another.');
    }

    const { hash, salt } = await hashPasswordAsync(payload.password);
    const newUser: StoredUser = {
      id: `user-${crypto.randomUUID ? crypto.randomUUID() : String(Date.now())}`,
      username: cleanUsername,
      fullName: payload.fullName.trim(),
      phone: payload.phone ? payload.phone.trim() : '',
      role: 'client',
      isActive: true,
      createdAt: new Date().toISOString(),
      passwordHash: hash,
      salt
    };

    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));

    const token = generateRandomToken();
    const sessions: StoredSession[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.SESSIONS) || '[]');
    sessions.push({
      token,
      userId: newUser.id,
      role: 'client',
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
    });
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));

    const { passwordHash: _, salt: __, ...safeUser } = newUser;
    return { user: safeUser, token };
  },

  async loginUser(username: string, password: string) {
    await initializeClientStore();
    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const cleanUsername = username.trim();
    const user = users.find(u => u.username.toLowerCase() === cleanUsername.toLowerCase());

    if (!user) {
      throw new Error('Invalid username or password.');
    }

    if (!user.isActive) {
      throw new Error('Your account has been deactivated. Please contact support.');
    }

    let isMatch = false;
    const check = await hashPasswordAsync(password, user.salt);
    if (check.hash === user.passwordHash) {
      isMatch = true;
    } else if (user.role === 'admin' && user.username.toLowerCase() === 'admin01' && password === 'Admin@01') {
      const refreshed = await hashPasswordAsync('Admin@01');
      user.passwordHash = refreshed.hash;
      user.salt = refreshed.salt;
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      isMatch = true;
    }

    if (!isMatch) {
      throw new Error('Invalid username or password.');
    }

    const token = generateRandomToken();
    const sessions: StoredSession[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.SESSIONS) || '[]');
    sessions.push({
      token,
      userId: user.id,
      role: user.role,
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
    });
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));

    const { passwordHash: _, salt: __, ...safeUser } = user;
    return { user: safeUser, token };
  },

  async loginAdmin(username: string, password: string) {
    await initializeClientStore();
    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const cleanUsername = username.trim();
    const admin = users.find(u => u.username.toLowerCase() === cleanUsername.toLowerCase() && u.role === 'admin');

    if (!admin) {
      throw new Error('Invalid administrator credentials.');
    }

    let isMatch = false;
    const check = await hashPasswordAsync(password, admin.salt);
    if (check.hash === admin.passwordHash) {
      isMatch = true;
    } else if (cleanUsername.toLowerCase() === 'admin01' && password === 'Admin@01') {
      const refreshed = await hashPasswordAsync('Admin@01');
      admin.passwordHash = refreshed.hash;
      admin.salt = refreshed.salt;
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      isMatch = true;
    }

    if (!isMatch) {
      throw new Error('Invalid administrator credentials.');
    }

    const token = generateRandomToken();
    const sessions: StoredSession[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.SESSIONS) || '[]');
    sessions.push({
      token,
      userId: admin.id,
      role: 'admin',
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000
    });
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));

    const { passwordHash: _, salt: __, ...safeUser } = admin;
    return { user: safeUser, token };
  },

  async getMe(token: string) {
    await initializeClientStore();
    const sessions: StoredSession[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.SESSIONS) || '[]');
    const session = sessions.find(s => s.token === token && s.expiresAt > Date.now());
    if (!session) {
      throw new Error('Session expired or invalid.');
    }

    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const user = users.find(u => u.id === session.userId);
    if (!user || !user.isActive) {
      throw new Error('User not found or inactive.');
    }

    const { passwordHash: _, salt: __, ...safeUser } = user;
    return { user: safeUser };
  },

  async logout(token: string) {
    const sessions: StoredSession[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.SESSIONS) || '[]');
    const updated = sessions.filter(s => s.token !== token);
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(updated));
    return { success: true };
  },

  // Public Contests & Prizes
  getContests(): DiyaContest[] {
    const data = localStorage.getItem(STORAGE_KEYS.CONTESTS);
    if (!data) return initialContests;
    try {
      return JSON.parse(data);
    } catch {
      return initialContests;
    }
  },

  getPrizes(contestId?: string): PrizeItem[] {
    const data = localStorage.getItem(STORAGE_KEYS.PRIZES);
    let prizes: PrizeItem[] = initialPrizes;
    if (data) {
      try {
        prizes = JSON.parse(data);
      } catch {
        prizes = initialPrizes;
      }
    }
    if (contestId && contestId !== 'all') {
      return prizes.filter(p => p.contestId === contestId);
    }
    return prizes.sort((a, b) => a.orderNumber - b.orderNumber);
  },

  getPaymentConfig(): PaymentConfig {
    const data = localStorage.getItem(STORAGE_KEYS.PAYMENT);
    if (!data) return initialPaymentConfig;
    try {
      return JSON.parse(data);
    } catch {
      return initialPaymentConfig;
    }
  },

  getSettings(): SiteSettings {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!data) return initialSiteSettings;
    try {
      return JSON.parse(data);
    } catch {
      return initialSiteSettings;
    }
  },

  getResults() {
    const settings = this.getSettings();
    const winnersData = localStorage.getItem(STORAGE_KEYS.WINNERS);
    const winners: WinnerRecord[] = winnersData ? JSON.parse(winnersData) : [];
    return {
      isResultPublished: settings.isResultPublished,
      announcementDate: settings.resultAnnouncementDate,
      displayDate: settings.resultDisplayDate,
      winners
    };
  },

  // Client Entries
  async submitEntry(payload: {
    contestId: string;
    fullName: string;
    phone: string;
    city: string;
    utrNumber: string;
    paymentMethod: string;
    receiptImage?: string;
    user: User;
  }) {
    await initializeClientStore();
    const contests = this.getContests();
    const contest = contests.find(c => c.id === payload.contestId);
    if (!contest) {
      throw new Error('Invalid contest category selected.');
    }

    const entries: ContestEntry[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.ENTRIES) || '[]');
    const duplicate = entries.find(e => e.utrNumber.toLowerCase() === payload.utrNumber.trim().toLowerCase() && e.status !== 'rejected');
    if (duplicate) {
      throw new Error('This Transaction Reference (UTR) has already been submitted.');
    }

    const ticketNumber = generateTicketNumber(payload.contestId);
    const newEntry: ContestEntry = {
      id: `entry-${crypto.randomUUID ? crypto.randomUUID() : String(Date.now())}`,
      ticketNumber,
      userId: payload.user.id,
      username: payload.user.username,
      fullName: payload.fullName.trim(),
      phone: payload.phone.trim(),
      city: payload.city.trim() || 'India',
      contestId: payload.contestId,
      contestTitle: contest.title,
      amount: contest.entryFee,
      utrNumber: payload.utrNumber.trim(),
      paymentMethod: payload.paymentMethod || 'UPI',
      receiptImage: payload.receiptImage,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    entries.unshift(newEntry);
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));

    return { success: true, entry: newEntry };
  },

  getMyEntries(userId: string): ContestEntry[] {
    const entries: ContestEntry[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.ENTRIES) || '[]');
    return entries.filter(e => e.userId === userId);
  },

  // Admin Operations
  getAdminStats(): AdminStats {
    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const entries: ContestEntry[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.ENTRIES) || '[]');
    const contests = this.getContests();

    const clientUsers = users.filter(u => u.role === 'client');
    const verifiedEntries = entries.filter(e => e.status === 'verified');
    const pendingEntries = entries.filter(e => e.status === 'pending');
    const totalCollected = verifiedEntries.reduce((acc, curr) => acc + curr.amount, 0);

    return {
      totalUsers: clientUsers.length,
      totalEntries: entries.length,
      pendingEntries: pendingEntries.length,
      verifiedEntries: verifiedEntries.length,
      totalCollected,
      activeContests: contests.filter(c => c.isActive).length
    };
  },

  getAdminUsers(search?: string) {
    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const entries: ContestEntry[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.ENTRIES) || '[]');

    let clientUsers = users
      .filter(u => u.role === 'client')
      .map(u => {
        const { passwordHash: _, salt: __, ...safeUser } = u;
        const userEntries = entries.filter(e => e.userId === u.id);
        return {
          ...safeUser,
          entriesCount: userEntries.length,
          verifiedEntriesCount: userEntries.filter(e => e.status === 'verified').length
        };
      });

    if (search) {
      const q = search.toLowerCase();
      clientUsers = clientUsers.filter(u =>
        u.username.toLowerCase().includes(q) ||
        u.fullName.toLowerCase().includes(q) ||
        (u.phone && u.phone.includes(q))
      );
    }
    return clientUsers;
  },

  toggleUserStatus(userId: string, isActive: boolean) {
    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const user = users.find(u => u.id === userId);
    if (!user) throw new Error('User not found.');
    user.isActive = isActive;
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    const { passwordHash: _, salt: __, ...safeUser } = user;
    return { user: safeUser };
  },

  async adminResetPassword(userId: string, newPassword: string) {
    const users: StoredUser[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const user = users.find(u => u.id === userId);
    if (!user) throw new Error('User not found.');
    const { hash, salt } = await hashPasswordAsync(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    return { success: true, message: `Password reset successfully.` };
  },

  getAdminEntries(params?: { status?: string; contestId?: string; search?: string }) {
    let entries: ContestEntry[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.ENTRIES) || '[]');
    if (params?.status && params.status !== 'all') {
      entries = entries.filter(e => e.status === params.status);
    }
    if (params?.contestId && params.contestId !== 'all') {
      entries = entries.filter(e => e.contestId === params.contestId);
    }
    if (params?.search) {
      const q = params.search.toLowerCase();
      entries = entries.filter(e =>
        e.ticketNumber.toLowerCase().includes(q) ||
        e.fullName.toLowerCase().includes(q) ||
        e.utrNumber.toLowerCase().includes(q) ||
        e.phone.includes(q)
      );
    }
    return entries;
  },

  updateEntryStatus(entryId: string, status: string, adminNotes?: string) {
    const entries: ContestEntry[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.ENTRIES) || '[]');
    const entry = entries.find(e => e.id === entryId);
    if (!entry) throw new Error('Entry not found.');
    entry.status = status as any;
    if (adminNotes) entry.adminNotes = adminNotes;
    if (status === 'verified') entry.verifiedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
    return { success: true, entry };
  },

  addPrize(prize: Partial<PrizeItem>) {
    const prizes: PrizeItem[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.PRIZES) || '[]');
    const newPrize: PrizeItem = {
      id: `prize-${Date.now()}`,
      contestId: prize.contestId || 'diya-1',
      orderNumber: prizes.length + 1,
      name: prize.name || 'Festive Prize',
      nameHi: prize.nameHi || prize.name || 'शुभ उपहार',
      category: prize.category || 'lifestyle',
      marketValue: prize.marketValue || '₹10,000',
      imageUrl: prize.imageUrl || '/images/diwali_prizes_showcase_1793461230644.jpg',
      description: prize.description || '',
      descriptionHi: prize.descriptionHi || '',
      isVerified: true
    };
    prizes.push(newPrize);
    localStorage.setItem(STORAGE_KEYS.PRIZES, JSON.stringify(prizes));
    return { success: true, prize: newPrize };
  },

  updatePrize(prizeId: string, updates: Partial<PrizeItem>) {
    const prizes: PrizeItem[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.PRIZES) || '[]');
    const idx = prizes.findIndex(p => p.id === prizeId);
    if (idx === -1) throw new Error('Prize not found.');
    prizes[idx] = { ...prizes[idx], ...updates };
    localStorage.setItem(STORAGE_KEYS.PRIZES, JSON.stringify(prizes));
    return { success: true, prize: prizes[idx] };
  },

  deletePrize(prizeId: string) {
    let prizes: PrizeItem[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.PRIZES) || '[]');
    prizes = prizes.filter(p => p.id !== prizeId);
    localStorage.setItem(STORAGE_KEYS.PRIZES, JSON.stringify(prizes));
    return { success: true };
  },

  updatePaymentConfig(config: Partial<PaymentConfig>) {
    const current = this.getPaymentConfig();
    const updated = { ...current, ...config, updatedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.PAYMENT, JSON.stringify(updated));
    return { success: true, paymentConfig: updated };
  },

  updateSettings(settings: Partial<SiteSettings>) {
    const current = this.getSettings();
    const updated = { ...current, ...settings, updatedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updated));
    return { success: true, settings: updated };
  },

  conductDraw() {
    const entries: ContestEntry[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.ENTRIES) || '[]');
    const verified = entries.filter(e => e.status === 'verified');
    if (verified.length === 0) {
      throw new Error('Cannot conduct draw: No verified participant entries found. Please approve payments first.');
    }

    const prizes = this.getPrizes();
    const contests = this.getContests();
    const newWinners: WinnerRecord[] = [];

    // Shuffle and pick winners
    ['diya-1', 'diya-2', 'diya-3'].forEach(contestId => {
      const contestEntries = verified.filter(e => e.contestId === contestId);
      if (contestEntries.length === 0) return;

      const contestPrizes = prizes.filter(p => p.contestId === contestId);
      const contest = contests.find(c => c.id === contestId);

      // Simple Fisher-Yates shuffle
      const shuffled = [...contestEntries].sort(() => Math.random() - 0.5);

      contestPrizes.slice(0, Math.min(contestPrizes.length, contestEntries.length)).forEach((prize, idx) => {
        const ticket = shuffled[idx % shuffled.length];
        const maskedUsername = ticket.username.length > 2
          ? ticket.username[0] + '***' + ticket.username.slice(-1)
          : ticket.username[0] + '***';

        const hash = Math.random().toString(36).substring(2, 10).toUpperCase();

        newWinners.push({
          id: `winner-${Date.now()}-${idx}`,
          contestId,
          contestTitle: contest?.title || contestId,
          ticketNumber: ticket.ticketNumber,
          prizeName: prize.name,
          prizeImageUrl: prize.imageUrl,
          winnerUsername: maskedUsername,
          winnerCity: ticket.city || 'Verified Indian Resident',
          drawnAt: new Date().toISOString(),
          drawAuditHash: `AUDIT-${hash}`
        });
      });
    });

    localStorage.setItem(STORAGE_KEYS.WINNERS, JSON.stringify(newWinners));
    return { success: true, count: newWinners.length, winners: newWinners };
  },

  publishResults(isPublished: boolean) {
    const settings = this.getSettings();
    settings.isResultPublished = isPublished;
    this.updateSettings(settings);
    return { success: true, isPublished };
  },

  getAuditLogs() {
    const data = localStorage.getItem(STORAGE_KEYS.AUDIT);
    return data ? JSON.parse(data) : [];
  }
};
