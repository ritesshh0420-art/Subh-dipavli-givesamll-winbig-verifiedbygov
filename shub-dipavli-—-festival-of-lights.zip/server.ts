import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import {
  loadDatabase,
  saveDatabase,
  hashPassword,
  verifyPassword,
  generateToken,
  generateTicketNumber,
  getStats,
  StoredUser,
  StoredSession
} from './server/db';
import { ContestEntry, PrizeItem } from './src/types';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Body parser
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Auth middleware helper
interface AuthenticatedRequest extends Request {
  user?: StoredUser;
  sessionToken?: string;
}

function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : null;

  if (!token) {
    return next();
  }

  const db = loadDatabase();
  const session = db.sessions.find(s => s.token === token && s.expiresAt > Date.now());

  if (session) {
    const user = db.users.find(u => u.id === session.userId);
    if (user && user.isActive) {
      req.user = user;
      req.sessionToken = token;
    }
  }

  next();
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Access restricted. Administrator privileges required.' });
  }
  next();
}

app.use(authenticateToken);

// ==========================================
// AUTHENTICATION ROUTES
// ==========================================

// Client Registration
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { username, fullName, password, phone } = req.body;

  if (!username || !fullName || !password) {
    return res.status(400).json({ error: 'Username, Full Name, and Password are required.' });
  }

  if (username.trim().length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters long.' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
  }

  if (username.trim().toLowerCase() === 'admin01') {
    return res.status(409).json({ error: 'This username is reserved for system administration.' });
  }

  const db = loadDatabase();
  const existingUser = db.users.find(u => u.username.toLowerCase() === username.trim().toLowerCase());

  if (existingUser) {
    return res.status(409).json({ error: 'This username is already taken. Please choose another.' });
  }

  const { hash, salt } = hashPassword(password);
  const newUser: StoredUser = {
    id: `user-${crypto.randomUUID()}`,
    username: username.trim(),
    fullName: fullName.trim(),
    phone: phone ? phone.trim() : '',
    role: 'client',
    isActive: true,
    createdAt: new Date().toISOString(),
    passwordHash: hash,
    salt
  };

  const token = generateToken();
  const session: StoredSession = {
    token,
    userId: newUser.id,
    role: 'client',
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000 // 30 days
  };

  db.users.push(newUser);
  db.sessions.push(session);
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'USER_REGISTERED',
    performedBy: newUser.username,
    details: `User ${newUser.username} created an account.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);

  const { passwordHash, salt: _, ...safeUser } = newUser;
  res.status(201).json({ user: safeUser, token });
});

// Client & Admin Unified Login
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Please enter both username and password.' });
  }

  const db = loadDatabase();
  const user = db.users.find(u => u.username.toLowerCase() === username.trim().toLowerCase());

  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  if (!user.isActive) {
    return res.status(403).json({ error: 'Your account has been deactivated. Please contact support.' });
  }

  let isValid = false;
  if (user.role === 'admin' && user.username.toLowerCase() === 'admin01' && password === 'Admin@01') {
    isValid = true;
  } else {
    isValid = verifyPassword(password, user.passwordHash, user.salt);
  }

  if (!isValid) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  const token = generateToken();
  const session: StoredSession = {
    token,
    userId: user.id,
    role: user.role,
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000
  };

  db.sessions.push(session);
  saveDatabase(db);

  const { passwordHash, salt: _, ...safeUser } = user;
  res.json({ user: safeUser, token });
});

// Admin Login endpoint (supports both direct and legacy admin callers)
app.post('/api/auth/admin-login', (req: Request, res: Response) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Admin username and password required.' });
  }

  const db = loadDatabase();
  const user = db.users.find(u => u.username.toLowerCase() === username.trim().toLowerCase() && u.role === 'admin');

  if (!user) {
    return res.status(401).json({ error: 'Invalid administrator credentials.' });
  }

  let isValid = false;
  if (user.username.toLowerCase() === 'admin01' && password === 'Admin@01') {
    isValid = true;
  } else {
    isValid = verifyPassword(password, user.passwordHash, user.salt);
  }

  if (!isValid) {
    return res.status(401).json({ error: 'Invalid administrator credentials.' });
  }

  const token = generateToken();
  const session: StoredSession = {
    token,
    userId: user.id,
    role: 'admin',
    expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 // 7 days
  };

  db.sessions.push(session);
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'ADMIN_LOGIN',
    performedBy: user.username,
    details: `Admin ${user.username} logged in to management console.`,
    timestamp: new Date().toISOString()
  });
  saveDatabase(db);

  const { passwordHash, salt: _, ...safeUser } = user;
  res.json({ user: safeUser, token });
});

// Current User Profile
app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { passwordHash, salt: _, ...safeUser } = user;
  res.json({ user: safeUser });
});

// Logout
app.post('/api/auth/logout', (req: AuthenticatedRequest, res: Response) => {
  if (req.sessionToken) {
    const db = loadDatabase();
    db.sessions = db.sessions.filter(s => s.token !== req.sessionToken);
    saveDatabase(db);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// Forgot Password Request
app.post('/api/auth/forgot-password', (req: Request, res: Response) => {
  const { username, phone, securityAnswer } = req.body;
  if (!username) {
    return res.status(400).json({ error: 'Username is required.' });
  }

  const db = loadDatabase();
  const user = db.users.find(u => u.username.toLowerCase() === username.trim().toLowerCase());

  if (!user) {
    return res.status(404).json({ error: 'No account found with this username.' });
  }

  // Record support ticket for admin
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'FORGOT_PASSWORD_REQUEST',
    performedBy: user.username,
    details: `Password reset requested for ${user.username} (Contact: ${phone || user.phone || 'N/A'}). Verification hint: ${securityAnswer || 'Standard'}`,
    timestamp: new Date().toISOString()
  });
  saveDatabase(db);

  res.json({
    success: true,
    message: 'Your password reset request has been logged. Our festival support team will verify your contact number and issue a secure temporary access key within 1 hour. You may also contact our WhatsApp helpline.'
  });
});

// ==========================================
// PUBLIC CONTENT & CONTEST ROUTES
// ==========================================

// Get all Diya categories
app.get('/api/contests', (_req: Request, res: Response) => {
  const db = loadDatabase();
  const contestsWithCounts = db.contests.map(c => {
    const prizesCount = db.prizes.filter(p => p.contestId === c.id).length;
    return { ...c, totalPrizes: prizesCount };
  });
  res.json({ contests: contestsWithCounts });
});

// Get prizes for a specific category or all prizes
app.get('/api/prizes', (req: Request, res: Response) => {
  const contestId = req.query.contestId as string;
  const db = loadDatabase();
  let prizes = db.prizes;

  if (contestId) {
    prizes = prizes.filter(p => p.contestId === contestId);
  }

  // Sort by orderNumber
  prizes.sort((a, b) => a.orderNumber - b.orderNumber);
  res.json({ prizes });
});

// Get active payment configuration
app.get('/api/payment-config', (_req: Request, res: Response) => {
  const db = loadDatabase();
  res.json({ paymentConfig: db.paymentConfig });
});

// Get site settings & countdown date
app.get('/api/settings', (_req: Request, res: Response) => {
  const db = loadDatabase();
  res.json({ settings: db.siteSettings });
});

// Get official published results
app.get('/api/results', (_req: Request, res: Response) => {
  const db = loadDatabase();
  res.json({
    isResultPublished: db.siteSettings.isResultPublished,
    announcementDate: db.siteSettings.resultAnnouncementDate,
    displayDate: db.siteSettings.resultDisplayDate,
    winners: db.winners
  });
});

// ==========================================
// PARTICIPATION & USER DASHBOARD ROUTES
// ==========================================

// Submit a paid participation entry
app.post('/api/entries', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { contestId, fullName, phone, city, utrNumber, paymentMethod, receiptImage } = req.body;

  if (!contestId || !fullName || !phone || !utrNumber) {
    return res.status(400).json({ error: 'All fields including Full Name, Phone, and UTR / Reference ID are required.' });
  }

  const cleanUtr = utrNumber.trim();
  if (cleanUtr.length < 6) {
    return res.status(400).json({ error: 'Please provide a valid Bank/UPI UTR or Reference Number (at least 6 alphanumeric characters).' });
  }

  const db = loadDatabase();
  const contest = db.contests.find(c => c.id === contestId);
  if (!contest) {
    return res.status(404).json({ error: 'Invalid Diya contest category selected.' });
  }

  // Check if UTR already submitted
  const duplicateEntry = db.entries.find(e => e.utrNumber.toLowerCase() === cleanUtr.toLowerCase() && e.status !== 'rejected');
  if (duplicateEntry) {
    return res.status(409).json({ error: 'This Transaction UTR reference has already been submitted for entry. Please verify your reference number.' });
  }

  const ticketNumber = generateTicketNumber(contestId);
  const newEntry: ContestEntry = {
    id: `entry-${crypto.randomUUID()}`,
    ticketNumber,
    userId: user.id,
    username: user.username,
    fullName: fullName.trim(),
    phone: phone.trim(),
    city: city ? city.trim() : 'India',
    contestId,
    contestTitle: contest.title,
    amount: contest.entryFee,
    utrNumber: cleanUtr,
    paymentMethod: paymentMethod || 'UPI',
    receiptImage: receiptImage || undefined,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  db.entries.unshift(newEntry);
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'CONTEST_ENTRY_SUBMITTED',
    performedBy: user.username,
    details: `Ticket ${ticketNumber} submitted for ${contest.title} (Amount: ₹${contest.entryFee}, UTR: ${cleanUtr}).`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.status(201).json({ success: true, entry: newEntry });
});

// Get user's own entries
app.get('/api/entries/my-entries', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const db = loadDatabase();
  const userEntries = db.entries.filter(e => e.userId === user.id);
  res.json({ entries: userEntries });
});

// ==========================================
// ADMIN DASHBOARD ROUTES
// ==========================================

// Get Admin Stats
app.get('/api/admin/stats', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  const stats = getStats();
  res.json({ stats });
});

// Get all users
app.get('/api/admin/users', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const search = (req.query.search as string || '').toLowerCase();

  let users = db.users
    .filter(u => u.role === 'client')
    .map(u => {
      const { passwordHash, salt: _, ...safeUser } = u;
      const userEntries = db.entries.filter(e => e.userId === u.id);
      return {
        ...safeUser,
        entriesCount: userEntries.length,
        verifiedEntriesCount: userEntries.filter(e => e.status === 'verified').length
      };
    });

  if (search) {
    users = users.filter(u =>
      u.username.toLowerCase().includes(search) ||
      u.fullName.toLowerCase().includes(search) ||
      (u.phone && u.phone.includes(search))
    );
  }

  res.json({ users });
});

// Toggle user status (suspend / reactivate)
app.patch('/api/admin/users/:id/status', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { isActive } = req.body;

  const db = loadDatabase();
  const user = db.users.find(u => u.id === id);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  user.isActive = Boolean(isActive);
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: user.isActive ? 'USER_REACTIVATED' : 'USER_SUSPENDED',
    performedBy: req.user!.username,
    details: `User ${user.username} was ${user.isActive ? 'reactivated' : 'suspended'}.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  const { passwordHash, salt: _, ...safeUser } = user;
  res.json({ user: safeUser });
});

// Admin reset user password
app.post('/api/admin/users/:id/reset-password', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { newPassword } = req.body;

  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  }

  const db = loadDatabase();
  const user = db.users.find(u => u.id === id);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const { hash, salt } = hashPassword(newPassword);
  user.passwordHash = hash;
  user.salt = salt;

  // Invalidate existing sessions for this user
  db.sessions = db.sessions.filter(s => s.userId !== user.id);

  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'ADMIN_RESET_PASSWORD',
    performedBy: req.user!.username,
    details: `Password reset for user ${user.username} by administrator.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, message: `Password for ${user.username} has been reset successfully.` });
});

// Get all entries for verification
app.get('/api/admin/entries', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const status = req.query.status as string;
  const contestId = req.query.contestId as string;
  const search = (req.query.search as string || '').toLowerCase();

  let entries = db.entries;

  if (status && status !== 'all') {
    entries = entries.filter(e => e.status === status);
  }

  if (contestId && contestId !== 'all') {
    entries = entries.filter(e => e.contestId === contestId);
  }

  if (search) {
    entries = entries.filter(e =>
      e.ticketNumber.toLowerCase().includes(search) ||
      e.username.toLowerCase().includes(search) ||
      e.fullName.toLowerCase().includes(search) ||
      e.utrNumber.toLowerCase().includes(search) ||
      e.phone.includes(search)
    );
  }

  res.json({ entries });
});

// Verify, Approve, Reject or Refund an entry
app.patch('/api/admin/entries/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { status, adminNotes } = req.body;

  if (!['pending', 'verified', 'rejected', 'refunded'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status provided.' });
  }

  const db = loadDatabase();
  const entry = db.entries.find(e => e.id === id);

  if (!entry) {
    return res.status(404).json({ error: 'Entry not found.' });
  }

  const oldStatus = entry.status;
  entry.status = status;
  entry.adminNotes = adminNotes || entry.adminNotes;
  if (status === 'verified') {
    entry.verifiedAt = new Date().toISOString();
  }

  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: `ENTRY_${status.toUpperCase()}`,
    performedBy: req.user!.username,
    details: `Ticket ${entry.ticketNumber} status changed from ${oldStatus} to ${status}. Notes: ${adminNotes || 'None'}`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, entry });
});

// Add Prize
app.post('/api/admin/prizes', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { contestId, name, nameHi, category, marketValue, imageUrl, description, descriptionHi } = req.body;

  if (!contestId || !name) {
    return res.status(400).json({ error: 'Contest ID and Prize Name are required.' });
  }

  const db = loadDatabase();
  const contestPrizes = db.prizes.filter(p => p.contestId === contestId);
  const nextOrder = contestPrizes.length + 1;

  const newPrize: PrizeItem = {
    id: `prize-${crypto.randomUUID()}`,
    contestId,
    orderNumber: nextOrder,
    name: name.trim(),
    nameHi: nameHi ? nameHi.trim() : name.trim(),
    category: category || 'lifestyle',
    marketValue: marketValue || 'Priceless',
    imageUrl: imageUrl || '/images/diwali_prizes_showcase_1793461230644.jpg',
    description: description || '',
    descriptionHi: descriptionHi || '',
    isVerified: true
  };

  db.prizes.push(newPrize);
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'PRIZE_ADDED',
    performedBy: req.user!.username,
    details: `Added new prize: ${newPrize.name} to ${contestId}.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.status(201).json({ success: true, prize: newPrize });
});

// Update Prize
app.put('/api/admin/prizes/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { name, nameHi, category, marketValue, imageUrl, description, descriptionHi, isVerified, orderNumber } = req.body;

  const db = loadDatabase();
  const prize = db.prizes.find(p => p.id === id);

  if (!prize) {
    return res.status(404).json({ error: 'Prize not found.' });
  }

  if (name !== undefined) prize.name = name.trim();
  if (nameHi !== undefined) prize.nameHi = nameHi.trim();
  if (category !== undefined) prize.category = category;
  if (marketValue !== undefined) prize.marketValue = marketValue;
  if (imageUrl !== undefined) prize.imageUrl = imageUrl;
  if (description !== undefined) prize.description = description;
  if (descriptionHi !== undefined) prize.descriptionHi = descriptionHi;
  if (isVerified !== undefined) prize.isVerified = Boolean(isVerified);
  if (orderNumber !== undefined) prize.orderNumber = Number(orderNumber);

  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'PRIZE_UPDATED',
    performedBy: req.user!.username,
    details: `Updated prize: ${prize.name}.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, prize });
});

// Delete Prize
app.delete('/api/admin/prizes/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();
  const index = db.prizes.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Prize not found.' });
  }

  const removed = db.prizes.splice(index, 1)[0];
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'PRIZE_DELETED',
    performedBy: req.user!.username,
    details: `Deleted prize: ${removed.name} from ${removed.contestId}.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, message: `Prize ${removed.name} removed.` });
});

// Update Payment & QR Config
app.put('/api/admin/payment-config', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { upiId, upiQrUrl, accountHolderName, bankName, accountNumber, ifscCode, paymentInstructions, isEnabled } = req.body;

  const db = loadDatabase();
  db.paymentConfig = {
    ...db.paymentConfig,
    upiId: upiId || db.paymentConfig.upiId,
    upiQrUrl: upiQrUrl || db.paymentConfig.upiQrUrl,
    accountHolderName: accountHolderName || db.paymentConfig.accountHolderName,
    bankName: bankName || db.paymentConfig.bankName,
    accountNumber: accountNumber || db.paymentConfig.accountNumber,
    ifscCode: ifscCode || db.paymentConfig.ifscCode,
    paymentInstructions: paymentInstructions || db.paymentConfig.paymentInstructions,
    isEnabled: isEnabled !== undefined ? Boolean(isEnabled) : db.paymentConfig.isEnabled,
    updatedAt: new Date().toISOString()
  };

  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'PAYMENT_CONFIG_UPDATED',
    performedBy: req.user!.username,
    details: `Updated UPI and Bank details. UPI ID: ${db.paymentConfig.upiId}, Enabled: ${db.paymentConfig.isEnabled}`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, paymentConfig: db.paymentConfig });
});

// Update Site Settings
app.put('/api/admin/settings', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const updates = req.body;

  db.siteSettings = {
    ...db.siteSettings,
    ...updates,
    updatedAt: new Date().toISOString()
  };

  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'SITE_SETTINGS_UPDATED',
    performedBy: req.user!.username,
    details: `Updated website settings and announcement configuration.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, settings: db.siteSettings });
});

// Conduct Fair Cryptographic Winner Draw (transparent selection)
app.post('/api/admin/draw', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const verifiedEntries = db.entries.filter(e => e.status === 'verified');

  if (verifiedEntries.length === 0) {
    return res.status(400).json({
      error: 'Cannot conduct draw: There are no verified entries yet. Please verify participant payments first.'
    });
  }

  // Group verified entries by contest
  const d1Entries = verifiedEntries.filter(e => e.contestId === 'diya-1');
  const d2Entries = verifiedEntries.filter(e => e.contestId === 'diya-2');
  const d3Entries = verifiedEntries.filter(e => e.contestId === 'diya-3');

  const newWinners: any[] = [];

  const drawForContest = (entries: ContestEntry[], contestId: string) => {
    if (entries.length === 0) return;
    const contest = db.contests.find(c => c.id === contestId);
    const contestPrizes = db.prizes.filter(p => p.contestId === contestId);

    // Pick winners for top featured prizes
    const shuffledPrizes = [...contestPrizes].sort((a, b) => a.orderNumber - b.orderNumber).slice(0, Math.min(contestPrizes.length, entries.length));

    // Fisher-Yates cryptographically seeded shuffle
    const shuffledTickets = [...entries];
    for (let i = shuffledTickets.length - 1; i > 0; i--) {
      const randomBytes = crypto.randomBytes(4);
      const j = randomBytes.readUInt32BE(0) % (i + 1);
      [shuffledTickets[i], shuffledTickets[j]] = [shuffledTickets[j], shuffledTickets[i]];
    }

    shuffledPrizes.forEach((prize, idx) => {
      const winningTicket = shuffledTickets[idx % shuffledTickets.length];
      const maskedUsername = winningTicket.username.length > 2
        ? winningTicket.username[0] + '***' + winningTicket.username.slice(-1)
        : winningTicket.username[0] + '***';

      const auditHash = crypto.createHash('sha256')
        .update(`${winningTicket.ticketNumber}-${prize.id}-${Date.now()}`)
        .digest('hex').substring(0, 16).toUpperCase();

      newWinners.push({
        id: `winner-${crypto.randomUUID()}`,
        contestId,
        contestTitle: contest?.title || contestId,
        ticketNumber: winningTicket.ticketNumber,
        prizeName: prize.name,
        prizeImageUrl: prize.imageUrl,
        winnerUsername: maskedUsername,
        winnerCity: winningTicket.city || 'Verified Indian Resident',
        drawnAt: new Date().toISOString(),
        drawAuditHash: auditHash
      });
    });
  };

  drawForContest(d1Entries, 'diya-1');
  drawForContest(d2Entries, 'diya-2');
  drawForContest(d3Entries, 'diya-3');

  db.winners = newWinners;
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: 'WINNER_DRAW_CONDUCTED',
    performedBy: req.user!.username,
    details: `Conducted transparent cryptographic draw for ${newWinners.length} prize allocations across verified tickets.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, count: newWinners.length, winners: newWinners });
});

// Toggle publish official results
app.post('/api/admin/publish-results', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { isPublished } = req.body;
  const db = loadDatabase();

  db.siteSettings.isResultPublished = Boolean(isPublished);
  db.auditLogs.push({
    id: crypto.randomUUID(),
    action: isPublished ? 'RESULTS_PUBLISHED_PUBLIC' : 'RESULTS_UNPUBLISHED',
    performedBy: req.user!.username,
    details: `Official results publication state changed to: ${isPublished}.`,
    timestamp: new Date().toISOString()
  });

  saveDatabase(db);
  res.json({ success: true, isPublished: db.siteSettings.isResultPublished });
});

// Get Audit Logs
app.get('/api/admin/audit-logs', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const logs = [...db.auditLogs].reverse().slice(0, 100);
  res.json({ logs });
});

// ==========================================
// VITE DEV SERVER / PRODUCTION SERVE
// ==========================================
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🪔 SHUB DIPAVLI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
